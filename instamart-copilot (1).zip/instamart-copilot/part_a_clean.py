"""Part A: audit raw data, clean customers/orders, store CSV + SQLite."""
import sqlite3
import numpy as np
import pandas as pd

RAW, CLEAN = "data/raw/", "data/clean/"
import os
for _d in ("data/clean", "outputs", "state", "sql"):
    os.makedirs(_d, exist_ok=True)
cust = pd.read_csv(RAW + "customers.csv")
prod = pd.read_csv(RAW + "products.csv")
orders = pd.read_csv(RAW + "orders.csv", keep_default_na=False, na_values=[""])  # keep literal "N/A" text visible
tickets = pd.read_csv(RAW + "tickets.csv", keep_default_na=False)

print("=== AUDIT: shape, dtypes, missing values ===")
for name, df in [("customers", cust), ("products", prod), ("orders", orders), ("tickets", tickets)]:
    print(f"\n[{name}] shape={df.shape}")
    audit = pd.DataFrame({"dtype": df.dtypes.astype(str), "missing": df.isna().sum(),
                          "missing_pct": (df.isna().mean() * 100).round(2)})
    print(audit.to_string())

amt_num = pd.to_numeric(orders["order_amount"], errors="coerce")
audit_figs = {
    "raw orders rows": len(orders),
    "exact duplicate rows": int(orders.duplicated().sum()),
    "pending rows": int((orders["status"] == "pending").sum()),
    "distinct order_id": int(orders["order_id"].nunique()),
    "non-numeric order_amount": int(amt_num.isna().sum()),
    "negative delivery_minutes": int((orders["delivery_minutes"] < 0).sum()),
    "blank delivery_minutes": int(orders["delivery_minutes"].isna().sum()),
    "customers: blank age": int(cust["age"].isna().sum()),
    "customers: age outside 10-100": int(((cust["age"] < 10) | (cust["age"] > 100)).sum()),
    "customers: distinct raw city spellings": int(cust["city"].nunique()),
    "customers: distinct non-blank gender spellings": int(cust["gender"].dropna().nunique()),
    "customers: blank gender": int(cust["gender"].isna().sum()),
}
print("\n=== AUDIT FIGURES ===")
for k, v in audit_figs.items():
    print(f"{k}: {v}")

# ---------------- clean customers ----------------
c = cust.copy()
c["city"] = c["city"].str.strip().str.title()
gmap = {"m": "male", "male": "male", "f": "female", "female": "female"}
c["gender"] = c["gender"].fillna("").str.strip().str.lower().map(gmap).fillna("unknown")
bad_age = (c["age"] < 10) | (c["age"] > 100)
c.loc[bad_age, "age"] = np.nan
n_missing_age = int(c["age"].isna().sum())
c["age"] = c["age"].fillna(c.groupby("city")["age"].transform("median")).round().astype(int)
c["signup_date"] = pd.to_datetime(c["signup_date"])
print("\n=== CLEAN CUSTOMERS ===")
print("age values set to missing (out of range):", int(bad_age.sum()))
print("ages filled with city median (total missing):", n_missing_age)
print(c["city"].value_counts().to_string())
print(c["gender"].value_counts().to_string())
print("missing ages:", int(c["age"].isna().sum()), "min/max age:", c["age"].min(), c["age"].max())

# ---------------- clean orders ----------------
o = orders.copy()
n0 = len(o)
o["order_ts"] = pd.to_datetime(o["order_ts"])
o = o.drop_duplicates()
n1 = len(o)
o = o.sort_values(["order_id", "order_ts"]).drop_duplicates("order_id", keep="last")
n2 = len(o)
o["order_amount"] = pd.to_numeric(o["order_amount"], errors="coerce")
bad_amt = o["order_amount"].isna()
o = o.merge(prod[["product_id", "category", "price_inr"]], on="product_id", how="left")
fill_amt = (o["price_inr"] * o["quantity"] * (1 - o["discount_pct"] / 100)).round(2)
o.loc[bad_amt.values, "order_amount"] = fill_amt[bad_amt.values]
neg = o["delivery_minutes"] < 0
o.loc[neg, "delivery_minutes"] = np.nan
completed = o["status"] == "completed"
med = o["delivery_minutes"].where(completed).groupby(o["category"]).transform("median")
fill_del = completed & o["delivery_minutes"].isna()
o.loc[fill_del, "delivery_minutes"] = med[fill_del]
o = o.drop(columns=["category", "price_inr"]).sort_values("order_id").reset_index(drop=True)
print("\n=== CLEAN ORDERS ===")
print("rule1 order_ts converted:", n0, "rows")
print("rule2 exact duplicates removed:", n0 - n1)
print("rule3 pending/older records removed:", n1 - n2)
print("rule4 unparseable amounts refilled from price:", int(bad_amt.sum()))
print("rule5a negative delivery set to missing:", int(neg.sum()))
print("rule5b completed delivery_minutes imputed (blank+negative):", int(fill_del.sum()))
print("rows:", len(o), o["status"].value_counts().to_dict())
print("missing amount:", int(o["order_amount"].isna().sum()),
      "| missing delivery completed:", int(o.loc[o.status == "completed", "delivery_minutes"].isna().sum()),
      "| missing delivery cancelled:", int(o.loc[o.status == "cancelled", "delivery_minutes"].isna().sum()))
print("completed revenue: INR %.2f" % o.loc[o.status == "completed", "order_amount"].sum())

# ---------------- store ----------------
o_out = o.copy()
o_out["order_ts"] = o_out["order_ts"].dt.strftime("%Y-%m-%d %H:%M:%S")
c_out = c.copy()
c_out["signup_date"] = c_out["signup_date"].dt.strftime("%Y-%m-%d")
c_out.to_csv(CLEAN + "customers.csv", index=False)
prod.to_csv(CLEAN + "products.csv", index=False)
o_out.to_csv(CLEAN + "orders.csv", index=False)
with sqlite3.connect("data/instamart.db") as con:
    c_out.to_sql("customers", con, if_exists="replace", index=False)
    prod.to_sql("products", con, if_exists="replace", index=False)
    o_out.to_sql("orders", con, if_exists="replace", index=False)
print("\nstored data/clean/*.csv and data/instamart.db")
