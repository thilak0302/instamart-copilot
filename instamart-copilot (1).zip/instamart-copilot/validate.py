"""Part A validation: asserts reference checkpoints; prints ALL CHECKPOINTS PASSED."""
import sqlite3
import pandas as pd

con = sqlite3.connect("data/instamart.db")
o = pd.read_sql_query("SELECT * FROM orders", con)
c = pd.read_sql_query("SELECT * FROM customers", con)
comp = o[o.status == "completed"]
canc = o[o.status == "cancelled"]
checks = [
    ("orders rows == 12309", len(o) == 12309),
    ("order_id unique", o.order_id.is_unique),
    ("completed == 11110", len(comp) == 11110),
    ("cancelled == 1199", len(canc) == 1199),
    ("no pending rows", (o.status == "pending").sum() == 0),
    ("0 missing order_amount", o.order_amount.isna().sum() == 0),
    ("0 missing delivery (completed)", comp.delivery_minutes.isna().sum() == 0),
    ("1199 missing delivery (cancelled)", canc.delivery_minutes.isna().sum() == 1199),
    ("completed revenue == 2998668.80", round(comp.order_amount.sum(), 2) == 2998668.80),
    ("six cities", c.city.nunique() == 6),
    ("city counts", c.city.value_counts().to_dict() == {"Pune": 227, "Delhi": 210, "Bengaluru": 197, "Chennai": 191, "Hyderabad": 191, "Mumbai": 184}),
    ("gender counts", c.gender.value_counts().to_dict() == {"female": 610, "male": 560, "unknown": 30}),
    ("0 missing ages, all 18-60", c.age.isna().sum() == 0 and c.age.between(18, 60).all()),
    ("tables exist", {"customers", "products", "orders"} <= set(pd.read_sql_query("SELECT name FROM sqlite_master", con).name)),
]
for name, ok in checks:
    print(("PASS " if ok else "FAIL ") + name)
assert all(ok for _, ok in checks), "a checkpoint failed"
print("ALL CHECKPOINTS PASSED")
