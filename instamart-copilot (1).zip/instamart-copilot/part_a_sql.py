"""Part A: run the seven SQL queries and the pandas cross-check / EDA."""
import re, sqlite3
import pandas as pd

con = sqlite3.connect("data/instamart.db")
text = open("sql/queries.sql", encoding="utf-8").read()
queries = {m.group(1): m.group(2).strip() for m in re.finditer(r"-- (Q\d):[^\n]*\n(.*?)(?=\n-- Q\d:|\Z)", text, re.S)}
assert len(queries) == 7
res = {k: pd.read_sql_query(q, con) for k, q in queries.items()}

print("Q1 customers:", len(res["Q1"]))
q2 = res["Q2"]
print("Q2 rows:", len(q2), "| sum: %.2f" % q2.revenue.sum(), "| largest:", q2.iloc[0].tolist())
print("Q3 products:", len(res["Q3"]))
print("Q4 customers without completed order:", len(res["Q4"]))
print("Q5 customers above average:", len(res["Q5"]), "| average: %.2f" % res["Q5"].avg_total.iloc[0])
q6 = res["Q6"]
print("Q6 top per city:")
print(q6[q6.row_num == 1][["city", "customer_id", "total_spend"]].to_string(index=False))
print("Q6 rows with RANK() != ROW_NUMBER():", int((q6.rnk != q6.row_num).sum()))
q7 = res["Q7"]
print("Q7 daily rows:", len(q7), "| last cumulative: %.2f" % q7.cumulative_revenue.iloc[-1])

# ---- pandas cross-check ----
o = pd.read_sql_query("SELECT * FROM orders WHERE status='completed'", con)
c = pd.read_sql_query("SELECT * FROM customers", con)
p = pd.read_sql_query("SELECT * FROM products", con)
m = o.merge(c[["customer_id", "city"]], on="customer_id").merge(p[["product_id", "category"]], on="product_id")
pv = pd.pivot_table(m, values="order_amount", index="city", columns="category", aggfunc="sum", margins=True, margins_name="Total")
print("\nPivot (margins=True):\n", pv.round(2).to_string())
print("pivot grand total: %.2f | SQL total: %.2f | equal: %s" % (pv.loc["Total", "Total"], q2.revenue.sum(), abs(pv.loc["Total", "Total"] - q2.revenue.sum()) < 0.01))
g = m.groupby("city").agg(sum=("order_amount", "sum"), mean=("order_amount", "mean"), count=("order_amount", "count")).round(2)
print("\nPer-city aggregation:\n", g.to_string())

a = o["order_amount"]
q1, q3 = a.quantile(.25), a.quantile(.75)
iqr = q3 - q1
lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
print("\nEDA order_amount: mean %.2f median %.2f skew %.2f Q1 %.2f Q3 %.2f IQR %.2f" % (a.mean(), a.median(), a.skew(), q1, q3, iqr))
print("fences: lower %.2f upper %.2f | below lower: %d | above upper: %d" % (lo, hi, (a < lo).sum(), (a > hi).sum()))
cm = o[["order_amount", "discount_pct", "quantity", "delivery_minutes"]].corr()
print("Correlation matrix:\n", cm.round(3).to_string())
pairs = {(i, j): cm.loc[i, j] for n, i in enumerate(cm.index) for j in cm.columns[n + 1:]}
best = max(pairs, key=lambda k: abs(pairs[k]))
print("largest |corr| pair:", best, round(pairs[best], 3))
