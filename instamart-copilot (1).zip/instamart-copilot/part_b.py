"""Part B: RFM, K-means segments, PCA, lapse model."""
import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, silhouette_score, accuracy_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.base import clone

pd.set_option("display.width", 200)
import os
os.makedirs("outputs", exist_ok=True)
orders = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
cust = pd.read_csv("data/clean/customers.csv", parse_dates=["signup_date"])
prod = pd.read_csv("data/clean/products.csv")
comp = orders[orders.status == "completed"].copy()

# ---------------- Task 1: RFM ----------------
SNAP = pd.Timestamp("2025-10-01 00:00:00")
rfm = comp.groupby("customer_id").agg(last=("order_ts", "max"), frequency=("order_id", "nunique"),
                                      monetary=("order_amount", "sum")).reset_index()
rfm["recency"] = (SNAP - rfm["last"]).dt.days
rfm = rfm[["customer_id", "recency", "frequency", "monetary"]]
print("=== TASK 1 RFM ===")
print("customers:", len(rfm), "| recency median %d min %d max %d" % (rfm.recency.median(), rfm.recency.min(), rfm.recency.max()))
print("frequency mean %.2f max %d | monetary mean %.2f max %.2f" % (rfm.frequency.mean(), rfm.frequency.max(), rfm.monetary.mean(), rfm.monetary.max()))

# ---------------- Task 2: K-means ----------------
X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
print("\n=== TASK 2 K-MEANS ===")
rows = []
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    rows.append((k, km.inertia_, silhouette_score(X, km.labels_)))
kt = pd.DataFrame(rows, columns=["K", "inertia", "silhouette"])
kt["inertia_drop_vs_prev"] = (-kt.inertia.diff()).round(1)
print(kt.round(3).to_string(index=False))
K = 4

# ---------------- Task 3: profile ----------------
km = KMeans(n_clusters=K, n_init=10, random_state=42).fit(X)
rfm["segment_id"] = km.labels_
prof = rfm.groupby("segment_id").agg(size=("customer_id", "count"), recency=("recency", "mean"),
                                    frequency=("frequency", "mean"), monetary=("monetary", "mean")).round(2)
print("\n=== TASK 3 SEGMENT PROFILE (K=4) ===")
print(prof.to_string())
premium_id = prof["monetary"].idxmax()
# name by profile (rule-based, so that names follow the data, not the arbitrary cluster number)
names = {}
for sid, r in prof.iterrows():
    if sid == premium_id:
        names[sid] = "Premium Big-Ticket Buyers"
    elif r["recency"] > prof["recency"].median() * 1.5 and r["frequency"] <= prof["frequency"].median():
        names[sid] = "Lapsing / Dormant"
    elif r["frequency"] == prof["frequency"].max():
        names[sid] = "Loyal Frequent Shoppers"
    else:
        names[sid] = "Occasional Low-Spend"
print("premium segment_id:", premium_id, "| names:", names)
rfm["segment_name"] = rfm.segment_id.map(names)
rfm["is_premium"] = rfm.segment_id == premium_id
pca = PCA(n_components=2).fit(X)
print("PCA explained_variance_ratio_:", pca.explained_variance_ratio_.round(3), "total %.3f" % pca.explained_variance_ratio_.sum())
rfm.to_csv("outputs/customer_segments.csv", index=False)
print("premium rows:", int(rfm.is_premium.sum()), "| names count:\n", rfm.groupby(["segment_id", "segment_name"]).size().to_string())

# ---------------- Task 4: lapse definition ----------------
CUT, END = pd.Timestamp("2025-09-01"), pd.Timestamp("2025-10-01")
pre = orders[orders.order_ts < CUT]                       # only orders before cutoff
pre_c = pre[pre.status == "completed"].merge(prod[["product_id", "category"]], on="product_id")
cohort_ids = pre_c.customer_id.unique()
feat = pre_c.groupby("customer_id").agg(last=("order_ts", "max"), frequency=("order_id", "nunique"),
                                        monetary=("order_amount", "sum"), avg_discount=("discount_pct", "mean"),
                                        avg_delivery=("delivery_minutes", "mean")).reset_index()
feat["recency"] = (CUT - feat["last"]).dt.days
fav = pre_c.groupby(["customer_id", "category"]).size().reset_index(name="n").sort_values(["customer_id", "n", "category"], ascending=[True, False, True])
feat = feat.merge(fav.drop_duplicates("customer_id")[["customer_id", "category"]].rename(columns={"category": "fav_category"}), on="customer_id")
canc = pre.groupby("customer_id").apply(lambda d: (d.status == "cancelled").mean(), include_groups=False).rename("cancel_rate").reset_index()
feat = feat.merge(canc, on="customer_id").merge(cust[["customer_id", "city", "age", "gender", "signup_date"]], on="customer_id")
feat["tenure_days"] = (CUT - feat["signup_date"]).dt.days
sept = comp[(comp.order_ts >= CUT) & (comp.order_ts < END)].customer_id.unique()
feat["lapsed"] = (~feat.customer_id.isin(sept)).astype(int)
NUM = ["recency", "frequency", "monetary", "avg_discount", "cancel_rate", "avg_delivery", "age", "tenure_days"]
CAT = ["city", "gender", "fav_category"]
y = feat["lapsed"]
Xf = feat[["customer_id"] + NUM + CAT]
Xtr, Xte, ytr, yte = train_test_split(Xf, y, test_size=0.2, stratify=y, random_state=42)
ids_te = Xte["customer_id"].values
Xtr, Xte = Xtr.drop(columns="customer_id"), Xte.drop(columns="customer_id")
print("\n=== TASK 4 LAPSE PROBLEM ===")
print("cohort:", len(feat), "| lapsed:", int(y.sum()), "(%.2f%%)" % (100 * y.mean()), "| train", len(Xtr), "test", len(Xte))
base = np.zeros(len(yte), dtype=int)
print("baseline always not-lapsed: accuracy %.1f%%, F1 %.3f" % (100 * accuracy_score(yte, base), f1_score(yte, base, zero_division=0)))
print("train lapsed:", int(ytr.sum()), "not lapsed:", int((ytr == 0).sum()))

# ---------------- Task 5: preprocessing ----------------
def prep():
    return ColumnTransformer([("num", StandardScaler(), NUM),
                              ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), CAT)])
print("\n=== TASK 5 PREPROCESSING ===")
p = prep().fit(Xtr)
print("scaler learned mean of frequency (train only): %.4f | full-cohort mean: %.4f" % (p.named_transformers_["num"].mean_[NUM.index("frequency")], feat.frequency.mean()))
print("missing values in feature columns:", int(Xf.drop(columns="customer_id").isna().sum().sum()))
assert Xf.drop(columns="customer_id").isna().sum().sum() == 0

# ---------------- Task 6: tune ----------------
print("\n=== TASK 6 TUNING ===")
lr_pipe = Pipeline([("prep", prep()), ("clf", LogisticRegression(max_iter=1000))])
gl = GridSearchCV(lr_pipe, {"clf__C": [0.01, 0.1, 1, 10, 100]}, cv=5, scoring="f1").fit(Xtr, ytr)
rf_pipe = Pipeline([("prep", prep()), ("clf", RandomForestClassifier(n_estimators=100, random_state=42))])
gr = GridSearchCV(rf_pipe, {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [5, 10, 20]}, cv=5, scoring="f1").fit(Xtr, ytr)
print("LR best:", gl.best_params_, "cv F1 %.4f" % gl.best_score_)
print("RF best:", gr.best_params_, "cv F1 %.4f" % gr.best_score_)
def metrics(m, X_=Xte):
    pr = m.predict(X_)
    return pr, dict(precision=precision_score(yte, pr, zero_division=0), recall=recall_score(yte, pr, zero_division=0), f1=f1_score(yte, pr, zero_division=0))
res = {}
for nm, g in [("LogisticRegression", gl), ("RandomForest", gr)]:
    pr, mt = metrics(g.best_estimator_)
    res[nm] = (g, mt)
    print(nm, "confusion [[TN FP][FN TP]]:", confusion_matrix(yte, pr).tolist(), {k: round(v, 3) for k, v in mt.items()})
sel_name = max(res, key=lambda n: res[n][1]["f1"])
sel = res[sel_name][0].best_estimator_
print("SELECTED:", sel_name, "test F1 %.3f" % res[sel_name][1]["f1"])
assert res[sel_name][1]["f1"] >= 0.55

# ---------------- Task 7: oversampling ----------------
print("\n=== TASK 7 CLASS BALANCE ===")
lapsed_idx = ytr[ytr == 1].index
n_add = int((ytr == 0).sum() - (ytr == 1).sum())
extra = pd.Series(lapsed_idx).sample(n=n_add, replace=True, random_state=42).values
Xbal = pd.concat([Xtr, Xtr.loc[extra]]); ybal = pd.concat([ytr, ytr.loc[extra]])
print("balanced train counts:", ybal.value_counts().to_dict(), "| added duplicates:", n_add)
lr_best = clone(gl.best_estimator_).fit(Xbal, ybal)
_, m_unb = metrics(gl.best_estimator_)
pr_b, m_bal = metrics(lr_best)
print("LR un-balanced:", {k: round(v, 3) for k, v in m_unb.items()})
print("LR over-sampled:", {k: round(v, 3) for k, v in m_bal.items()}, "confusion:", confusion_matrix(yte, pr_b).tolist())
print("deltas:", {k: round(m_bal[k] - m_unb[k], 3) for k in m_bal})

# ---------------- Task 8: interpret, persist, use ----------------
print("\n=== TASK 8 INTERPRET / PERSIST / USE ===")
rf_best = gr.best_estimator_
names_out = rf_best.named_steps["prep"].get_feature_names_out()
imp = pd.Series(rf_best.named_steps["clf"].feature_importances_, index=names_out).sort_values(ascending=False)
print("RF top-5 importances:\n", imp.head(5).round(4).to_string())
lr_fit = gl.best_estimator_
coef = pd.Series(lr_fit.named_steps["clf"].coef_[0], index=lr_fit.named_steps["prep"].get_feature_names_out()).sort_values()
print("LR coefficients (most negative / most positive):\n", pd.concat([coef.head(4), coef.tail(4)]).round(4).to_string())
print("LR key coefs:", {k: round(coef[k], 4) for k in ["num__recency", "num__frequency", "num__avg_discount", "num__cancel_rate", "num__monetary"]})
joblib.dump(sel, "outputs/lapse_model.joblib")
re = joblib.load("outputs/lapse_model.joblib")
same = np.array_equal(re.predict(Xte), sel.predict(Xte)) and np.allclose(re.predict_proba(Xte), sel.predict_proba(Xte))
print("reloaded model reproduces test predictions exactly:", same)
assert same
prob = sel.predict_proba(Xte)[:, 1]
te = pd.DataFrame({"customer_id": ids_te, "lapse_probability": prob.round(4), "actually_lapsed": yte.values})
prem = set(rfm.loc[rfm.is_premium, "customer_id"])
ret = te[te.customer_id.isin(prem)].sort_values("lapse_probability", ascending=False).head(10)
ret.to_csv("outputs/retention_list.csv", index=False)
print("test-set premium customers:", int(te.customer_id.isin(prem).sum()), "| retention list rows:", len(ret), "| truly lapsed:", int(ret.actually_lapsed.sum()))
print(ret.to_string(index=False))
