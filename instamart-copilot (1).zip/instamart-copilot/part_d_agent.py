"""Part D (tasks 5-8): tools, ReAct loop, safe stopping, checkpoint/resume."""
import json, os, sqlite3, time, uuid
from datetime import datetime, timezone
import pandas as pd
import mock_llm
from part_d_rag import retrieve

DB, LEDGER, STATE_DIR = "data/instamart.db", "outputs/refund_ledger.jsonl", "state"
_CTX = {"run_id": None}                      # set by the loop so ledger lines can be traced to a run

# ---------------- tools ----------------
def get_order(order_id):
    with sqlite3.connect(DB) as con:
        row = con.execute("SELECT order_id, status, order_amount, delivery_minutes FROM orders WHERE order_id = ?", (order_id,)).fetchone()
    if row is None:
        return {"error": "order not found"}
    return {"order_id": row[0], "status": row[1], "order_amount": row[2], "delivery_minutes": row[3]}

def search_policy(query):
    return {"results": retrieve(query, 3)}

def calculate_refund(order_amount, delivery_minutes):
    """Full refund if delivered in more than 45 minutes, else 0. (Status is checked by the agent before this tool.)"""
    if delivery_minutes is not None and float(delivery_minutes) > 45 and order_amount is not None:
        return {"refund_inr": round(float(order_amount), 2)}
    return {"refund_inr": 0}

def _ledger(tool, order_id, refund_inr):
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    with open(LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"), "tool": tool,
                            "run_id": _CTX["run_id"], "order_id": order_id, "refund_inr": refund_inr}) + "\n")
    return {"refund_inr": refund_inr}

def issue_refund(order_id, refund_inr):
    return _ledger("issue_refund", order_id, refund_inr)

def escalate_to_human(order_id, refund_inr):
    return _ledger("escalate_to_human", order_id, refund_inr)

def _spec(name, desc, props):
    return {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props, "required": list(props)}}
TOOLS_SPEC = [
    _spec("get_order", "Look up an order's status, amount and delivery time in the database.", {"order_id": {"type": "string"}}),
    _spec("search_policy", "Search the policy documents and return the three most relevant passages.", {"query": {"type": "string"}}),
    _spec("calculate_refund", "Compute the refund in INR from the order amount and delivery minutes.", {"order_amount": {"type": "number"}, "delivery_minutes": {"type": "number"}}),
    _spec("issue_refund", "Issue an automatic refund (amount up to INR 1000) and record it in the ledger.", {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}),
    _spec("escalate_to_human", "Send a refund above INR 1000 to a human support lead and record it in the ledger.", {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}),
]
TOOL_MAP = {"get_order": get_order, "search_policy": search_policy, "calculate_refund": calculate_refund,
            "issue_refund": issue_refund, "escalate_to_human": escalate_to_human}

AGENT_SYSTEM = ("You are a refund AGENT for a grocery delivery company. Use the tools to look up the order, check the policy, "
                "compute the refund and then issue it or escalate it. Finish with one line starting with REFUND, ESCALATE, DENIED or NOT_FOUND.")

class SimulatedCrash(Exception):
    pass

# ---------------- loop ----------------
def _save(st):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(os.path.join(STATE_DIR, f"{st['run_id']}.json"), "w", encoding="utf-8") as f:
        json.dump(st, f, indent=1, default=str)

def _fallback(st, status, reason):
    last = st["tools_executed"][-1] if st["tools_executed"] else "none"
    summary = (f"HANDOFF to human agent: automatic processing stopped ({reason}) after {len(st['steps'])} tool step(s); "
               f"last tool: {last}; request: {st['user_message'][:80]}")
    return {"run_id": st["run_id"], "scenario_id": st["scenario_id"], "status": status, "final_answer": summary,
            "steps": st["steps"], "llm_calls": st["llm_calls"], "tokens_used": st["tokens_used"]}

def _loop(st, crash_after_tools=None):
    _CTX["run_id"] = st["run_id"]
    start = time.monotonic()
    while True:
        if time.monotonic() - start >= st["time_limit_seconds"]:                 # (c) timeout, checked at the top
            return _fallback(st, "FALLBACK_TIMEOUT", f"time limit {st['time_limit_seconds']}s reached")
        if st["llm_calls"] >= st["max_iterations"]:                              # (a) iteration cap
            return _fallback(st, "FALLBACK_MAX_ITERATIONS", f"{st['max_iterations']} model calls without a final answer")
        resp = mock_llm.chat(st["messages"], TOOLS_SPEC)
        st["llm_calls"] += 1
        st["tokens_used"] += resp.usage.total_tokens
        if st["tokens_used"] > st["token_limit"]:                                # (b) token cap, before any tool runs
            return _fallback(st, "FALLBACK_TOKEN_LIMIT", f"token limit {st['token_limit']} exceeded")
        msg = resp.choices[0].message
        if not msg.tool_calls:
            final = msg.content or ""
            return {"run_id": st["run_id"], "scenario_id": st["scenario_id"], "status": final.split(":")[0].strip(),
                    "final_answer": final, "steps": st["steps"], "llm_calls": st["llm_calls"], "tokens_used": st["tokens_used"]}
        tc = msg.tool_calls[0]
        st["messages"].append({"role": "assistant", "content": None,
                               "tool_calls": [{"id": tc.id, "name": tc.name, "arguments": tc.arguments}]})
        fn = TOOL_MAP.get(tc.name)
        obs = fn(**tc.arguments) if fn else {"error": f"unknown tool {tc.name}"}
        st["messages"].append({"role": "tool", "tool_call_id": tc.id, "name": tc.name, "content": json.dumps(obs)})
        st["steps"].append({"tool": tc.name, "arguments": tc.arguments, "observation": obs})
        st["tools_executed"].append(tc.name)
        st["step"] = len(st["steps"])
        _save(st)                                                                # checkpoint after every observation
        if crash_after_tools is not None and len(st["tools_executed"]) == crash_after_tools:
            raise SimulatedCrash(f"simulated crash after tool #{crash_after_tools}")

def run_agent(user_message, scenario_id, max_iterations=6, token_limit=6000, time_limit_seconds=10, run_id=None, crash_after_tools=None):
    st = {"run_id": run_id or f"{scenario_id}-{uuid.uuid4().hex[:8]}", "scenario_id": scenario_id, "user_message": user_message,
          "messages": [{"role": "system", "content": AGENT_SYSTEM}, {"role": "user", "content": user_message}],
          "tokens_used": 0, "step": 0, "llm_calls": 0, "tools_executed": [], "steps": [],
          "max_iterations": max_iterations, "token_limit": token_limit, "time_limit_seconds": time_limit_seconds}
    return _loop(st, crash_after_tools)

def resume_agent(run_id):
    with open(os.path.join(STATE_DIR, f"{run_id}.json"), encoding="utf-8") as f:
        st = json.load(f)
    return _loop(st)

def refund_of(res):
    for s in reversed(res["steps"]):
        if s["tool"] in ("issue_refund", "escalate_to_human"):
            return s["observation"]["refund_inr"]
    return 0

if __name__ == "__main__":
    os.makedirs("outputs", exist_ok=True); os.makedirs(STATE_DIR, exist_ok=True)
    for p in (LEDGER, "outputs/agent_runs.jsonl", "outputs/agent_demo_runs.jsonl"):   # fresh, reproducible outputs
        open(p, "w").close()
    for fn in os.listdir(STATE_DIR) if os.path.isdir(STATE_DIR) else []:
        if fn.endswith(".json"): os.remove(os.path.join(STATE_DIR, fn))
    sc = pd.read_csv("data/raw/agent_scenarios.csv")

    print("=== TASK 6 SEVEN SCENARIOS ===")
    print("scenario | status | refund_inr | expected | model_calls | tokens")
    for r in sc.itertuples():
        res = run_agent(r.message, r.scenario_id, run_id=f"{r.scenario_id}-main")
        amt = refund_of(res)
        exp_status = r.expected_outcome
        ok = (res["status"].startswith("FALLBACK") if exp_status == "FALLBACK" else res["status"] == exp_status) and abs(amt - r.expected_refund_inr) < 0.01
        print(f"{r.scenario_id} | {res['status']} | {amt:.2f} | {r.expected_refund_inr:.2f} ({exp_status}) | {res['llm_calls']} | {res['tokens_used']} | match={ok}")
        with open("outputs/agent_runs.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({"scenario_id": r.scenario_id, "status": res["status"], "final_answer": res["final_answer"],
                                "llm_calls": res["llm_calls"], "tokens_used": res["tokens_used"],
                                "steps": [{"tool": s["tool"], "arguments": s["arguments"], "observation": s["observation"]} for s in res["steps"]]}) + "\n")
        assert ok, "scenario mismatch"

    s1 = sc.iloc[0]
    print("\n=== TASK 7 STOP SAFELY ===")
    d1 = run_agent(s1.message, "S1", token_limit=200, run_id="S1-token200")
    print("S1 token_limit=200 ->", d1["status"], "| calls", d1["llm_calls"], "| tokens", d1["tokens_used"], "| steps done:", [x["tool"] for x in d1["steps"]])
    print("   final_answer:", d1["final_answer"])
    d2 = run_agent(s1.message, "S1", time_limit_seconds=0, run_id="S1-timeout0")
    print("S1 time_limit_seconds=0 ->", d2["status"], "| calls", d2["llm_calls"], "| steps", len(d2["steps"]))
    print("   final_answer:", d2["final_answer"])
    s7 = sc[sc.scenario_id == "S7"].iloc[0]
    d3 = run_agent(s7.message, "S7", run_id="S7-check")
    print("S7 default limits ->", d3["status"], "| calls", d3["llm_calls"], "| tokens", d3["tokens_used"])
    for d, tag in [(d1, "S1_token_limit_200"), (d2, "S1_time_limit_0"), (d3, "S7_default")]:
        with open("outputs/agent_demo_runs.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({"demo": tag, "scenario_id": d["scenario_id"], "status": d["status"], "final_answer": d["final_answer"],
                                "llm_calls": d["llm_calls"], "tokens_used": d["tokens_used"], "steps": d["steps"]}) + "\n")

    print("\n=== TASK 8 CRASH AND RESUME (S1) ===")
    try:
        run_agent(s1.message, "S1", run_id="S1-crash", crash_after_tools=2)
    except SimulatedCrash as e:
        ck = json.load(open("state/S1-crash.json"))
        print("crash:", e, "| checkpoint keys:", sorted(ck), "| tools executed before crash:", ck["tools_executed"])
    res = resume_agent("S1-crash")
    ck = json.load(open("state/S1-crash.json"))
    print("resumed ->", res["status"], "| refund", refund_of(res), "| total llm_calls", res["llm_calls"], "| tokens", res["tokens_used"])
    print("tools executed across crash+resume, in order:", ck["tools_executed"])
    assert ck["tools_executed"] == ["get_order", "search_policy", "calculate_refund", "issue_refund"]
    assert res["status"] == "REFUND" and abs(refund_of(res) - 128.25) < 0.01
    print("\nledger lines:", sum(1 for _ in open(LEDGER)), "| state files:", sorted(os.listdir(STATE_DIR)))
