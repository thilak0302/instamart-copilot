# Instamart Customer Intelligence & Support Copilot

## Overview

One repository that turns messy order exports into a trusted database (Part A), segments customers and predicts who will lapse (Part B), triages support tickets safely (Part C), and answers policy questions and decides refund requests with a tool-using agent (Part D). All data is synthetic (produced by the unmodified `generate_data.py`); all money is in INR; every model call goes through the unmodified offline `mock_llm.py` (no API key, no network).

| Path | Purpose |
|---|---|
| `generate_data.py`, `mock_llm.py` | Supplied files, committed unmodified |
| `part_a_clean.py` | Audit, cleaning, CSV + SQLite storage |
| `validate.py` | Reference-checkpoint assertions (prints `ALL CHECKPOINTS PASSED`) |
| `sql/queries.sql`, `part_a_sql.py` | Seven SQL queries, runner, pandas cross-check and EDA |
| `part_b.py` | RFM, K-means, PCA, lapse model |
| `part_c.py` | Ticket triage pipeline |
| `part_d_rag.py` | Chunking, TF-IDF retrieval, grounded answers, evaluation |
| `part_d_agent.py` | Tools, ReAct loop, safe stopping, checkpoint/resume |
| `outputs/*_log.txt` | Console output of each script (source of the numbers below) |
| `state/` | Agent checkpoints (one JSON per run id) |

Environment used: Python 3.13, pandas 3.1.1, numpy 2.5.4, scikit-learn 1.9.1, joblib 1.6.0 (pinned in `requirements.txt`).

## Reproduce

Run from the repository root, in order:

1. `python -m venv .venv`
2. `source .venv/bin/activate`  (Windows: `.venv\Scripts\activate`)
3. `pip install -r requirements.txt`
4. `python generate_data.py`  (last line: `generated: customers=1200 products=40 orders_raw=13084 tickets=164`)
5. `python part_a_clean.py`  (audit, cleaning, writes `data/clean/*.csv` and `data/instamart.db`)
6. `python validate.py`  (prints `ALL CHECKPOINTS PASSED`)
7. `python part_a_sql.py`  (runs `sql/queries.sql`, pandas cross-check, EDA)
8. `python part_b.py`  (writes `outputs/customer_segments.csv`, `lapse_model.joblib`, `retention_list.csv`)
9. `python part_c.py`  (needs step 8; writes `outputs/triage_results.csv`, `triage_budget_demo.csv`)
10. `python part_d_rag.py`  (chunking, retrieval, evaluation)
11. `python part_d_agent.py`  (needs step 5; writes `outputs/agent_runs.jsonl`, `refund_ledger.jsonl`, `state/`; it first empties those outputs so re-runs are reproducible)

Everything is seeded (`random_state=42` everywhere; the generator uses `random.Random(42)`).

---

## Part A — Data Foundation

### A1. Audit of the raw data

Shapes: customers (1200, 5), products (40, 4), orders (13084, 9), tickets (164, 5). Missing values per column (count / %), as pandas sees blanks:

| Table | Column | dtype | Missing | % |
|---|---|---|---|---|
| customers | age | float64 | 61 | 5.08 |
| customers | gender | str | 30 | 2.50 |
| customers | customer_id, city, signup_date | str | 0 | 0.00 |
| products | all four columns | str / int64 | 0 | 0.00 |
| orders | delivery_minutes | float64 | 2541 | 19.42 |
| orders | all other columns (order_amount is read as text, so `N/A` and `error` stay visible) | mixed | 0 | 0.00 |
| tickets | all columns (read with `keep_default_na=False`; empty texts stay `""`) | str | 0 | 0.00 |

Audit figures (all equal the brief's references):

| Figure | Value |
|---|---|
| Raw order rows | 13,084 |
| Exact duplicate rows | 119 |
| Rows with status pending | 656 |
| Distinct order_id | 12,309 |
| Non-numeric order_amount | 120 |
| Negative delivery_minutes | 106 |
| Blank delivery_minutes | 2,541 |
| Blank age | 61 |
| Ages outside 10–100 | 6 |
| Distinct raw city spellings | 24 |
| Distinct non-blank gender spellings | 10 |
| Blank gender | 30 |

### A2. Cleaning customers

| Rule | Effect |
|---|---|
| (a) City: strip spaces + title case | 24 spellings → 6 cities: Pune 227, Delhi 210, Bengaluru 197, Chennai 191, Hyderabad 191, Mumbai 184 |
| (b) Gender: m/M/male/MALE → male, f/F/female/FEMALE → female, blank → unknown | female 610, male 560, unknown 30 |
| (c) Ages outside 10–100 set to missing, then every missing age filled with the median age of the customer's city (`groupby("city").transform("median")`) | 6 invalid values blanked; 67 ages filled (61 blank + 6 invalid); 0 missing, min 18, max 60 |
| (d) `signup_date` → datetime | 1,200 values converted |

### A3. Cleaning orders (rules applied in this order)

| # | Rule | Rows / values changed |
|---|---|---|
| 1 | Convert `order_ts` to datetime | 13,084 values |
| 2 | Remove exact duplicate rows | 119 rows removed |
| 3 | For each `order_id` keep only the record with the latest `order_ts` (removes the earlier *pending* records) | 656 rows removed → 12,309 rows, one per order |
| 4 | `order_amount` → numeric (unparseable → missing), then fill from `round(price_inr × quantity × (1 − discount_pct/100), 2)` | 112 amounts refilled (120 raw bad values, 8 of them sat on rows already removed by rules 2–3) |
| 5a | Negative `delivery_minutes` → missing | 105 values (106 raw, 1 was on a removed duplicate) |
| 5b | Completed orders: fill missing `delivery_minutes` with the median of the order's product category among completed orders (`groupby` + `transform`); cancelled orders stay missing (never delivered, imputing would invent data) | 774 completed orders imputed |

Result: 12,309 rows; 11,110 completed, 1,199 cancelled, 0 pending; 0 missing `order_amount`; 0 missing `delivery_minutes` among completed and 1,199 among cancelled; completed revenue **INR 2,998,668.80**. `order_ts` is stored as text `YYYY-MM-DD HH:MM:SS`.

### A4. Storage and validation

`data/clean/customers.csv`, `products.csv`, `orders.csv` and the SQLite database `data/instamart.db` (tables `customers`, `products`, `orders`) are written by `part_a_clean.py`. `validate.py` asserts 14 checkpoints (row counts, status counts, no pending, missing values, revenue, six cities, city counts, gender counts, ages 18–60, tables exist) and prints `ALL CHECKPOINTS PASSED`.

### A5. SQL analysis (`sql/queries.sql`, executed with `pd.read_sql_query`)

| Query | Result (matches reference) |
|---|---|
| Q1 WHERE then HAVING (completed, amount > 500, customer total > 8000) | 30 customers |
| Q2 three-table join, revenue by city × category | 30 rows; sum INR 2,998,668.80; largest cell Bengaluru / Electronics INR 233,909.45 |
| Q3 scalar subquery, price above catalogue average | 11 products |
| Q4 LEFT JOIN, customers without a completed order | 25 customers |
| Q5 CTEs, customers above the average spend | 550 customers; average INR 2,552.06 |
| Q6 RANK / DENSE_RANK / ROW_NUMBER per city | top per city: Bengaluru C0082 12,856.20; Chennai C0930 10,151.40; Delhi C0291 13,742.60; Hyderabad C0743 12,730.05; Mumbai C0693 14,766.55; Pune C0426 10,377.10; 8 rows have RANK ≠ ROW_NUMBER |
| Q7 daily revenue + running total | 183 daily rows; last cumulative value INR 2,998,668.80 |

**Why ties cause RANK ≠ ROW_NUMBER:** tied customers receive the *same* RANK (and the next rank is skipped), whereas ROW_NUMBER always hands out unique consecutive numbers, so every row from the second member of a tie onward gets a different value in the two columns.

### A6. pandas cross-check and exploratory analysis

`pd.pivot_table(..., margins=True)` of revenue by city × category has grand total INR 2,998,668.80, **equal** to the SQL total (Q2).

Per city (completed orders, `groupby` + named aggregation):

| City | Sum (INR) | Mean (INR) | Count |
|---|---|---|---|
| Bengaluru | 523,643.40 | 276.47 | 1,894 |
| Chennai | 463,629.15 | 272.72 | 1,700 |
| Delhi | 502,829.80 | 243.62 | 2,064 |
| Hyderabad | 528,589.90 | 284.95 | 1,855 |
| Mumbai | 479,058.50 | 297.00 | 1,613 |
| Pune | 500,918.05 | 252.48 | 1,984 |

Completed `order_amount` statistics: mean 269.91, median 135.00, skewness 4.61, Q1 64.80, Q3 297.00, IQR 232.20; 1.5×IQR fences: lower −283.50, upper 645.30; outliers below the lower fence 0, above the upper fence 897.

Correlation matrix (completed orders):

| | order_amount | discount_pct | quantity | delivery_minutes |
|---|---|---|---|---|
| order_amount | 1.000 | −0.095 | 0.087 | −0.003 |
| discount_pct | −0.095 | 1.000 | −0.000 | −0.010 |
| quantity | 0.087 | −0.000 | 1.000 | −0.013 |
| delivery_minutes | −0.003 | −0.010 | −0.013 | 1.000 |

**Four questions (under 200 words).**
*What is the data about?* 11,110 completed quick-commerce orders (April–September 2025) across six Indian cities: amount, quantity, discount and delivery time per order.
*Distributions?* Order amounts are strongly right-skewed: mean 269.91 against median 135.00, skewness 4.61, middle half between 64.80 and 297.00.
*Outliers?* 897 orders exceed the upper fence of 645.30 and none fall below. About 71% of them are Electronics, so they are genuine expensive purchases, not errors; the real anomalies (duplicates, negative delivery times, unparseable amounts) were fixed during cleaning.
*Relationships?* All correlations are weak. The largest in absolute value is order_amount with discount_pct (−0.095), because a discount mechanically lowers the amount; order_amount with quantity is +0.087. Delivery time is unrelated to everything (|r| ≤ 0.013). Correlation of this size does not establish causation.

---

## Part B — Customer Segments and Lapse Prediction

### B1. RFM table (snapshot 2025-10-01 00:00:00, completed orders only)

| Metric | Value |
|---|---|
| Customers with ≥ 1 completed order | 1,175 |
| Recency (days) | median 19, min 0, max 180 |
| Frequency | mean 9.46, max 33 |
| Monetary (INR) | mean 2,552.06, max 14,766.55 |

### B2. K-means (StandardScaler on R, F, M; `KMeans(n_clusters=K, n_init=10, random_state=42)`)

| K | Inertia | Silhouette | Drop in inertia vs K−1 |
|---|---|---|---|
| 2 | 1820.8 | 0.465 | – |
| 3 | 1268.2 | 0.445 | 552.5 |
| **4** | **743.1** | **0.526** | 525.2 |
| 5 | 617.4 | 0.480 | 125.7 |
| 6 | 503.2 | 0.482 | 114.2 |
| 7 | 408.5 | 0.416 | 94.7 |
| 8 | 366.5 | 0.412 | 42.0 |

All values are within tolerance of the reference. **Elbow:** the inertia falls steeply up to K=4 (drops of ~550 and ~525) and then flattens (drops of ~126 and below). **Choice: K = 4**: it sits at the elbow, has the best silhouette of all K (0.526), and gives four segments the business can act on (K=3 merges the big spenders with others; K=5 only splits small groups for a worse silhouette).

**Why K=8 has lower inertia than K=2 but that cannot pick K:** inertia is the within-cluster sum of squares, which can only shrink as more centroids are added (at K = n every point is its own cluster and inertia is 0), so the lowest inertia always goes to the largest K. The useful signal is where the *improvement* stops being worthwhile (the elbow) together with silhouette and interpretability.

### B3. Segment profile (K=4)

*Cluster numbers are arbitrary labels with no ordering; they carry no rank.*

| segment_id | Name | Size | Mean recency (days) | Mean frequency | Mean monetary (INR) | Recommended action |
|---|---|---|---|---|---|---|
| 0 | Occasional Low-Spend | 436 | 28.9 | 3.8 | 1,057.62 | Bundle offers and free-delivery nudges to raise basket size |
| 1 | **Premium Big-Ticket Buyers** (is_premium = true) | 138 | 24.1 | 6.8 | 7,129.70 | Early access to Electronics launches, priority support, white-glove retention |
| 2 | Loyal Frequent Shoppers | 419 | 8.8 | 19.4 | 3,410.02 | Loyalty points and subscription (grocery/dairy) to protect habit |
| 3 | Lapsing / Dormant | 182 | 109.0 | 2.2 | 685.99 | Win-back coupon campaign |

Sizes, means and the Premium flag match the references (the 138-customer segment has mean monetary ≈ 7,130 and frequency ≈ 6.8; the 419-customer segment has frequency ≈ 19.4 and recency ≈ 8.8). Premium = the segment with the highest mean monetary value (segment 1, 138 customers).

**PCA (2 components on the scaled RFM matrix):** explained_variance_ratio_ = 0.634 and 0.218, total 0.852.

`outputs/customer_segments.csv` columns: customer_id, recency, frequency, monetary, segment_id, segment_name, is_premium (1,175 rows).

### B4. Lapse problem

Cutoff 2025-09-01. Cohort = customers with ≥ 1 completed order before the cutoff. `lapsed = 1` when there is no completed order from 2025-09-01 to 2025-09-30.

| Item | Value |
|---|---|
| Cohort | 1,156 customers |
| Lapsed | 443 (38.32%) |
| Train / test (`test_size=0.2`, stratified, `random_state=42`) | 924 / 232 |
| Baseline “always not lapsed” on test | accuracy 61.6%, lapsed-class F1 0.000 |

Features (built **only from orders dated before 2025-09-01** plus the clean customer table): recency (days from cutoff to last completed order), frequency, monetary, average discount_pct, cancellation rate (cancelled ÷ all final-status orders before the cutoff), average delivery_minutes, favourite product category, city, age, gender, tenure in days.

**Leakage statement:** no order dated on or after 2025-09-01 entered any feature, and the segment labels from Part B task 3 were **not** used as features.

### B5. Preprocessing without leakage

A scikit-learn `ColumnTransformer` inside a `Pipeline`: `StandardScaler` on the eight numeric features and `OneHotEncoder(drop="first", handle_unknown="ignore")` on city, gender and favourite category (k−1 columns per variable). **No encoder, scaler or resampler saw test rows**; they are fitted on the training rows only (inside `GridSearchCV` they are refitted on each fold's training part).

| Quantity | Value |
|---|---|
| Learned mean of frequency in the fitted scaler (924 training rows) | 8.1147 |
| Full-cohort mean of frequency (1,156 customers) | 8.0285 |
| Feature columns with missing values | 0 (asserted in code) |

They differ because the scaler only sees the training customers, a random 80% subset whose average is not identical to the whole cohort's average.

### B6. Tuning and evaluation (positive class = lapsed)

| Model | Grid | Best parameters | Best CV F1 |
|---|---|---|---|
| LogisticRegression(max_iter=1000) | C ∈ {0.01, 0.1, 1, 10, 100}, cv=5, f1 | C = 100 | 0.651 |
| RandomForest(n_estimators=100, random_state=42) | max_depth ∈ {3, 5, 8} × min_samples_leaf ∈ {5, 10, 20}, cv=5, f1 (45 fits) | max_depth = 8, min_samples_leaf = 10 | 0.681 |

(The best C differs from the reference's C = 1 because I added extra features (cancellation rate, delivery time, tenure); the scores are of the same order.)

Untouched test set (232 rows), confusion matrix as [[TN, FP], [FN, TP]]:

| Model | Confusion | Precision | Recall | F1 |
|---|---|---|---|---|
| Baseline (always 0) | [[143, 0], [89, 0]] | 0.000 | 0.000 | 0.000 |
| Logistic regression | [[111, 32], [31, 58]] | 0.644 | 0.652 | 0.648 |
| Random forest | [[113, 30], [31, 58]] | 0.659 | 0.652 | **0.655** |

**Selected model: random forest** (test F1 0.655 ≥ 0.55 required). Justification: it has the higher cross-validated and test F1 and slightly higher precision at identical recall, and it can capture non-linear effects. Missing a customer who is about to lapse loses their future revenue, whereas wrongly targeting a loyal customer only costs a small coupon, so recall deserves at least as much weight as precision; at the same recall the forest wastes fewer offers (30 false positives against 32). The difference between the two models is small, so the retention team can equally use the balanced logistic regression below when recall matters most.

### B7. Class-balance experiment

The training set was over-sampled by adding 216 randomly chosen duplicates of lapsed training rows (`random_state=42`, with replacement) so both classes have 570 rows; the original test set was not touched. The best logistic regression was refitted on the balanced data.

| Logistic regression | Precision | Recall | F1 | Confusion |
|---|---|---|---|---|
| Original training data | 0.644 | 0.652 | 0.648 | [[111, 32], [31, 58]] |
| Over-sampled training data | 0.589 | 0.854 | 0.697 | [[90, 53], [13, 76]] |
| Change | −0.055 | **+0.202** | +0.049 | |

**Recall moved most** (0.65 → 0.85) while precision did not rise (it fell to 0.59): the model now flags many more customers as at risk, catching 76 of 89 true lapsers (versus 58) at the price of 21 more false alarms. For the retention team this is the right trade when a coupon is cheap relative to a lost customer, but the campaign budget must cover roughly 129 targeted customers instead of 90.

### B8. Interpretation, persistence and use

Top five random-forest features (importance): frequency 0.280, monetary 0.271, recency 0.115, average delivery minutes 0.061, cancellation rate 0.053. Business reading: how often and how much someone has bought dominate; how recently they bought matters next; slow deliveries and cancellations are secondary service signals.

Logistic-regression coefficients (standardised features; positive = higher lapse risk):

| Feature | Coefficient | Business reading |
|---|---|---|
| frequency | −1.697 (negative) | The more orders before September, the less likely to lapse: habit protects retention |
| recency | +0.039 (positive) | A longer gap since the last order raises the lapse risk (small effect once frequency is controlled) |
| cancellation rate | −0.124 (negative, small) | No meaningful service-driven effect here; treat as noise rather than a rule |

(Other notable signs: monetary +0.283, favourite category Electronics −1.135, i.e. electronics buyers are stickier.)

**Persistence:** the selected model (the whole fitted pipeline) was saved with `joblib.dump` to `outputs/lapse_model.joblib`, reloaded with `joblib.load`, and reproduces the original test predictions and probabilities **exactly** (checked with `np.array_equal`).

**Retention list:** 40 test-set customers belong to the Premium segment; the top 10 by predicted lapse probability were written to `outputs/retention_list.csv` (customer_id, lapse_probability, actually_lapsed); **1 of the 10 truly lapsed**. The Premium flag comes from the whole-window RFM that includes September, so this retention list is illustrative and not a leakage-free evaluation.

---

## Part C — Support Ticket Triage with Guardrails

Pipeline (`part_c.py`): empty/long guardrails → PII redaction → budget check → model call with retry → output validation → routing. Tickets are processed in file order, and `mock_llm.reset()` is called immediately before every full run.

### C1. Input guardrails

| Check | Count |
|---|---|
| Empty or whitespace-only tickets (`skipped_empty`, never sent) | 4 |
| Tickets with est_tokens > 400 (`flagged_long`, never sent) | 4 (each estimates to 734 tokens) |
| Tickets eligible for the model | 156 |

### C2. Redaction (applied in the order email → phone → order id)

| Type | Placeholder | Substitutions |
|---|---|---|
| Email | [EMAIL] | 55 |
| Phone | [PHONE] | 91 |
| Order id | [ORDER_ID] | 132 |
| **Total** | | **278** |

Re-applying the three patterns to the redacted texts finds 0 matches. The user message is exactly the redacted text; the code asserts that no email, phone number or order id appears in any message (system or user) of any of the 156 prompts sent.

### C3. Prompts

*Zero-shot* (24 estimated tokens): “You CLASSIFY support tickets. Allowed categories: billing, delivery, technical, fraud. Reply with JSON only: {"category": "...", "reason": "..."}”. It does not contain `EXAMPLES:`.
*Few-shot* (104 estimated tokens): the same text plus a line `EXAMPLES:` and four labelled examples (billing, fraud, technical, delivery).

### C4. Resilient calls

Every call goes through a retry wrapper: at most 3 retries per ticket, wait = `0.05 × 2**n × random.uniform(0.9, 1.15)` s, one log line per retry (`retry ticket=T0002 retry_number=0 wait=0.0544s`; the full lines are in `outputs/part_c_log.txt`).

| Run | TransientLLMErrors | Recovered by a retry | Permanent errors | Retry number used | Wait range |
|---|---|---|---|---|---|
| Zero-shot | 19 | 19 | 0 | always 0 | 0.0451–0.0567 s |
| Few-shot | 19 | 19 | 0 | always 0 | 0.0465–0.0568 s |

### C5. Output validation

Reply parsed as JSON → accepted if `category` is one of the four (`classified_json`). Otherwise the lowercase words from `re.findall(r"[a-z]+", text.lower())` are extracted and the reply is accepted if exactly one category word appears (`classified_keyword`, e.g. “billing-related” gives billing). Anything else, including valid JSON with category “shipping”, becomes `flagged_invalid_output` and goes to a human; nothing is guessed.

| Status (one full run, 164 tickets) | Count |
|---|---|
| classified_json | 135 |
| classified_keyword | 12 |
| flagged_invalid_output | 9 |
| skipped_empty | 4 |
| flagged_long | 4 |

### C6. Zero-shot versus few-shot (no budget)

| Run | Classified | Correct | Accuracy | Total tokens | Tokens per classified ticket |
|---|---|---|---|---|---|
| Zero-shot | 147 | 126 | 85.7% | 8,152 | 55.5 |
| Few-shot | 147 | 147 | 100.0% | 20,632 | 140.4 |

Zero-shot confusion table (rows = true, columns = predicted):

| true \ predicted | billing | delivery | fraud | technical |
|---|---|---|---|---|
| billing | 38 | 0 | 0 | 0 |
| delivery | 0 | 36 | 0 | 0 |
| fraud | **11** | 0 | 23 | 0 |
| technical | **10** | 0 | 0 | 29 |

All 21 errors are fraud tickets read as billing (11) or technical tickets read as billing (10).

**When are the few-shot tokens worth paying for?** The few-shot prompt costs 80 more tokens per call (104 vs 24), which raises the cost per classified ticket from 55.5 to 140.4 tokens (about 2.5 times, +12,480 tokens over the run) but fixes all 21 mistakes (85.7% → 100%), roughly 590 extra tokens per ticket corrected. That is clearly worth it when a mistake is expensive: the 11 fraud tickets that zero-shot sends to the billing queue would miss the 2-hour security-team escalation. For low-stakes categories, or when the budget is tight, the cheaper zero-shot prompt plus human review of uncertain tickets can be enough. (The mock classifier is keyword-based, so 100% is a property of the mock, not a promise for a real model.)

### C7. Token budget, routing and outputs

**Budget demo:** zero-shot with `TOKEN_BUDGET = 6000` (prompt of 24 estimated tokens) → **41 tickets ended `budget_exhausted`** (no model call; 6,012 tokens consumed when the budget was reached); saved as `outputs/triage_budget_demo.csv` (budget used: 6000).

**Final run:** `outputs/triage_results.csv` (164 rows) comes from the few-shot run with `TOKEN_BUDGET = 100000` (20,632 tokens used, budget never reached). Routing reads `outputs/customer_segments.csv`: skipped/long/invalid/budget-exhausted → `human_review` (NORMAL); else fraud → `security_team` (HIGH); else premium → `premium_desk` (HIGH); else `support_queue` (NORMAL). Customers without a segment row count as not premium (all 164 tickets' customers had a row).

| Route | Priority | Tickets |
|---|---|---|
| human_review | NORMAL | 17 (4 empty + 4 long + 9 invalid output) |
| security_team | HIGH | 34 |
| premium_desk | HIGH | 11 |
| support_queue | NORMAL | 102 |

**Which outputs were rule-validated and which went to humans:** the 147 tickets with status `classified_json` / `classified_keyword` passed the JSON or single-keyword validation and were routed automatically; the 17 others (4 empty, 4 too long, 9 with an invalid model answer) went to human review, because the system never guesses.

---

## Part D — Policy RAG Assistant and Refund Agent

### D1. Chunking (40 words, overlap 10)

15 chunks: refund 4, delivery 3, escalation 3, payment 3, privacy 2 (equal to the reference). Each chunk records its source file.

### D2. Retrieval

`TfidfVectorizer()` is fitted on the chunk texts; the query is transformed with the same vectorizer and chunks are ranked by cosine similarity (`retrieve(query, k=3)` returns dictionaries with source, score, text). For “refund policy late delivery” the three top chunks all come from `refund_policy.txt` (scores 0.272, 0.251, 0.245).

**TF and IDF:** TF (term frequency) measures how often a word occurs in a chunk, so a chunk that repeats a query word scores higher; IDF (inverse document frequency) measures how rare a word is across all chunks, so rare, informative words count more than common ones. **Limitation:** TF-IDF matches exact words only, so a question phrased as “money back” would not match a policy sentence that says “refund”, and it cannot tell that two phrasings mean the same thing.

### D3. Augment and answer

`answer(question)` retrieves three chunks and sends two messages to `mock_llm.chat`: a system message containing “POLICY ASSISTANT” (answer only from the context, otherwise say the information could not be found) and a user message `CONTEXT:\n[file.txt]\n<chunk> ... \nQUESTION:\n<question>`. It returns the text and the three sources. Example: “Who must approve a refund above INR 1000?” → “A refund above INR 1000 must be approved by a human support lead before money is returned.”

### D4. Evaluation (`data/raw/policy_eval.csv`: 12 answerable, 2 unanswerable)

| Setting | Chunks | expected_doc in top-3 (of 12) | expected_fact in answer (of 12) | Fallback “I could not find…” (of 2) |
|---|---|---|---|---|
| Overlap 10 | 15 | 12 | 12 | 2 |
| Overlap 0 | 13 | 12 | **10** | 2 |

With overlap 0 two answerable questions break, because the answer sentence is cut across a chunk boundary and the model only sees one half:
- “What delivery time makes a completed order eligible for a full refund?” — the phrase “more than 45 minutes” ends up in a different chunk from “receives a full refund…”, so the answer returned is “receives a full refund of the order amount.” without the expected fact.
- “How soon is money returned when a payment fails but is deducted?” — “…returned automatically” and “within 48 hours” are separated, so “48 hours” is missing from the answer.

The 10-word overlap keeps these sentences together.

### D5. Tools and tool map

`TOOLS_SPEC` lists five tools, each with a name, one-sentence description and a JSON-style parameter spec; `TOOL_MAP` maps name → Python function.

| Tool | Behaviour |
|---|---|
| get_order(order_id) | Reads `data/instamart.db`; returns order_id, status, order_amount, delivery_minutes, or `{"error": "order not found"}` |
| search_policy(query) | Returns `{"results": retrieve(query)}` using the Part D retrieval |
| calculate_refund(order_amount, delivery_minutes) | Delivery > 45 min → full order amount; otherwise 0 |
| issue_refund(order_id, refund_inr) | Appends a JSON line (timestamp, tool, run_id, order_id, refund_inr) to `outputs/refund_ledger.jsonl` |
| escalate_to_human(order_id, refund_inr) | Same, for refunds above INR 1000 (never auto-issued) |

### D6. ReAct loop

`run_agent(user_message, scenario_id, max_iterations=6, token_limit=6000, time_limit_seconds=10)` starts with a system message containing “AGENT”, calls `chat`, executes the requested tool through `TOOL_MAP`, appends the assistant tool-call message and the tool message (`content` is the JSON string of the result), and loops. Status is the word before the colon of the final answer. Each run is appended to `outputs/agent_runs.jsonl` (scenario_id, status, final_answer, llm_calls, tokens_used and every step's tool, arguments, observation).

| Scenario | Status | Refund (INR) | Expected | Model calls | Tokens used |
|---|---|---|---|---|---|
| S1 | REFUND | 128.25 | 128.25 | 5 | 1,107 |
| S2 | REFUND | 135.00 | 135.00 | 5 | 1,107 |
| S3 | ESCALATE | 1,999.00 | 1,999.00 | 5 | 1,094 |
| S4 | DENIED (on-time delivery) | 0.00 | 0.00 | 4 | 773 |
| S5 | DENIED (cancelled order) | 0.00 | 0.00 | 3 | 463 |
| S6 | NOT_FOUND | 0.00 | 0.00 | 2 | 156 |
| S7 | FALLBACK_MAX_ITERATIONS | 0.00 | 0.00 | 6 | 3,252 |

All amounts equal `expected_refund_inr` within 0.01. S7 (the `[LOOP]` scenario) finishes all six model calls under the default `token_limit=6000`. `outputs/refund_ledger.jsonl` contains the 4 recorded actions (S1 and S2 issued, S3 escalated, plus the S1 re-issue from the crash-and-resume demo, which is a separate run id `S1-crash`).

### D7. Stop safely

| Demonstration | Result |
|---|---|
| S1 with `token_limit=200` | **FALLBACK_TOKEN_LIMIT** after 3 model calls (480 tokens); the third requested tool was not executed; steps kept: get_order, search_policy |
| S1 with `time_limit_seconds=0` | **FALLBACK_TIMEOUT** before the first model call (0 calls, 0 steps) |
| S7 (default limits) | FALLBACK_MAX_ITERATIONS (6 calls) |

Implementation: the timeout is checked at the top of each iteration (`time.monotonic() - start >= time_limit_seconds`), the iteration cap after `max_iterations` model calls, and the token cap right after each model call (before any tool runs). Every fallback returns the steps completed so far and a short human-handoff string, e.g. “HANDOFF to human agent: automatic processing stopped (token limit 200 exceeded) after 2 tool step(s); last tool: search_policy; request: …”. The demonstration runs are stored in `outputs/agent_demo_runs.jsonl` so that `agent_runs.jsonl` keeps exactly one line per scenario.

### D8. Checkpoint and resume

After every tool observation the loop writes `state/<run_id>.json` (run id, scenario id, full message list, tokens_used, step number, tools executed so far, plus the steps, call count and limits). `resume_agent(run_id)` loads it and continues. Demonstration on S1: a simulated crash was raised right after the second tool execution (after its checkpoint was saved), then `resume_agent("S1-crash")` finished the run.

Tools executed across the crash and the resume, in order: **get_order → search_policy → (crash) → calculate_refund → issue_refund** (four executions, none repeated). Final status REFUND, INR 128.25, 5 model calls in total, 1,107 tokens.

### D9. ReAct versus plan-and-execute (about 230 words)

My ReAct agent calls the model once per step: 5 calls for S1/S2/S3, 4 for S4, 3 for S5 and 2 for S6, and 1,107 tokens for S1. Every call re-sends the whole conversation, including the ~200-token policy passages, which is why tokens grow with each step (S7 reaches 3,252 tokens in six calls). A plan-and-execute design asks the model once for the whole list (get_order, search_policy, calculate_refund, issue_refund) and runs it without more calls; I estimate 2–3 calls and fewer tokens for the happy path (this is an estimate, not measured).

The difference shows on unexpected observations. ReAct reacts immediately: after `NOT_FOUND` (S6) it stops after 2 calls, and after a cancelled order (S5) it stops after the policy search without calculating anything. A static plan would still contain calculate_refund and issue_refund, so it needs a replan call or guard code to avoid running steps that no longer make sense, and a wrongly executed issue_refund moves money.

For this refund workflow I would choose ReAct: the flow is short (at most 5 calls), the extra tokens are small, each decision uses the latest observation (status, delivery time, the INR 1000 escalation threshold), and its step-by-step checkpoints make crash recovery and audit simple. Plan-and-execute becomes attractive only for long, predictable workflows where model cost dominates.

---

## Limitations and Next Steps

- **Retention list is illustrative.** The Premium flag comes from the whole-window RFM that includes September (the window that defines the lapse label), so it is a post-hoc whole-window label and `outputs/retention_list.csv` is illustrative, not a leakage-free evaluation. A production version should compute the segment as of the cutoff date. In this sample only 1 of the 10 listed customers actually lapsed, and the highest predicted probability is only 0.49: Premium customers are rarely at risk in this synthetic data.
- **Small test set.** 232 test customers (89 lapsers) means the F1 difference between the two models (0.648 vs 0.655) is within noise; repeated cross-validation or a time-based split would be sturdier. The over-sampled model is a better fit when recall is the priority.
- **Synthetic, mock-driven results.** The ticket classifier and the agent's decisions come from `mock_llm.py`, which is keyword/rule-based, so 100% few-shot accuracy and the clean agent behaviour do not transfer to a real model. Prompts, guardrails and retries should be re-evaluated with a real LLM.
- **Imputation choices.** Median fills (age by city, delivery time by product category) hide real variation; a flag column for imputed values would help downstream models.
- **TF-IDF retrieval** matches exact words only; embeddings or a hybrid retriever would handle paraphrases (“money back”). Chunk size and overlap are fixed at 40/10 words.
- **Agent scope.** The 7-day refund window is assumed satisfied in the simulations; the agent handles one tool call per step; the ledger is an append-only file with no idempotency guard (re-running the same scenario issues a second simulated refund).
- **Next steps:** time-based lapse validation with rolling cutoffs, probability calibration, automatic re-running of `validate.py` in CI, a database-backed ledger with idempotency keys, and human-in-the-loop review screens for the 17 tickets and for escalated refunds.
