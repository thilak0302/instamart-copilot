"""Part D (tasks 1-4): chunking, TF-IDF retrieval, grounded answers, evaluation."""
import glob, os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import mock_llm

POLICY_DIR = os.path.join("data", "policies")

def chunk_words(words, size=40, overlap=10):
    """Windows of `size` words; next window starts `size-overlap` later; stop after the first window reaching the last word."""
    step, chunks, start = size - overlap, [], 0
    while True:
        chunks.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
        start += step
    return chunks

def load_chunks(size=40, overlap=10):
    out = []
    for path in sorted(glob.glob(os.path.join(POLICY_DIR, "*.txt"))):
        with open(path, encoding="utf-8") as f:
            words = f.read().split()
        for c in chunk_words(words, size, overlap):
            out.append({"source": os.path.basename(path), "text": c})
    return out

class Retriever:
    def __init__(self, size=40, overlap=10):
        self.chunks = load_chunks(size, overlap)
        self.vec = TfidfVectorizer()
        self.matrix = self.vec.fit_transform([c["text"] for c in self.chunks])

    def retrieve(self, query, k=3):
        sims = cosine_similarity(self.vec.transform([query]), self.matrix)[0]
        order = sims.argsort()[::-1][:k]
        return [{"source": self.chunks[i]["source"], "score": float(sims[i]), "text": self.chunks[i]["text"]} for i in order]

_DEFAULT = Retriever()
def retrieve(query, k=3):
    return _DEFAULT.retrieve(query, k)

SYSTEM = ("You are a POLICY ASSISTANT for the support team. Answer ONLY from the supplied context. "
          "If the context does not contain the answer, reply that you could not find the information in the policy documents.")

def answer(question, retriever=None):
    hits = (retriever or _DEFAULT).retrieve(question, 3)
    context = "\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)
    user = f"CONTEXT:\n{context}\nQUESTION:\n{question}"
    resp = mock_llm.chat([{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}])
    return resp.choices[0].message.content, [h["source"] for h in hits]

def evaluate(retriever, verbose=True):
    ev = pd.read_csv("data/raw/policy_eval.csv", keep_default_na=False)
    doc_ok = fact_ok = fb_ok = n_ans = n_un = 0
    fails = []
    for r in ev.itertuples():
        text, sources = answer(r.question, retriever)
        if r.expected_doc == "NONE":
            n_un += 1
            fb_ok += text.startswith("I could not find")
        else:
            n_ans += 1
            d, f = r.expected_doc in sources, r.expected_fact in text
            doc_ok += d; fact_ok += f
            if not (d and f):
                fails.append((r.question, r.expected_doc, r.expected_fact, d, f, text))
    return dict(answerable=n_ans, doc_in_top3=doc_ok, fact_in_answer=fact_ok, unanswerable=n_un, fallback=fb_ok), fails

if __name__ == "__main__":
    print("=== TASK 1 CHUNKS (size 40, overlap 10) ===")
    ch = load_chunks()
    print("total:", len(ch), pd.Series([c["source"] for c in ch]).value_counts().sort_index().to_dict())
    print("\n=== TASK 2 RETRIEVAL: 'refund policy late delivery' ===")
    for h in retrieve("refund policy late delivery"):
        print(f"  {h['source']}  score={h['score']:.3f}  {h['text'][:70]}...")
    print("\n=== TASK 3 EXAMPLE ANSWER ===")
    t, s = answer("Who must approve a refund above INR 1000?")
    print("answer:", t, "| sources:", s)
    print("\n=== TASK 4 EVALUATION (overlap 10) ===")
    r10, f10 = evaluate(Retriever(40, 10))
    print(r10)
    for f in f10: print("  FAIL", f)
    print("\n=== TASK 4 EVALUATION (overlap 0) ===")
    print("chunks with overlap 0:", len(Retriever(40, 0).chunks))
    r0, f0 = evaluate(Retriever(40, 0))
    print(r0)
    for q, doc, fact, d, f, text in f0:
        print(f"  FAIL q={q!r} expected_doc={doc} doc_in_top3={d} fact_in_answer={f}\n       expected_fact={fact!r}\n       answer={text!r}")
