"""Part C: support-ticket triage with guardrails, retries, validation, token budget and routing."""
import json, random, re, time
import pandas as pd
import mock_llm
from mock_llm import est_tokens, TransientLLMError

MAX_INPUT_TOKENS = 400
MAX_RETRIES = 3
BASE_DELAY = 0.05
CATEGORIES = ["billing", "delivery", "technical", "fraud"]
PATTERNS = [("EMAIL", re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[EMAIL]"),
            ("PHONE", re.compile(r"\b[6-9]\d{9}\b"), "[PHONE]"),
            ("ORDER_ID", re.compile(r"ORD-\d{6}"), "[ORDER_ID]")]

ZERO_SHOT = ('You CLASSIFY support tickets. Allowed categories: billing, delivery, technical, fraud. '
             'Reply with JSON only: {"category": "...", "reason": "..."}')
FEW_SHOT = (ZERO_SHOT + "\nEXAMPLES:\n"
            'Ticket: I was charged twice for [ORDER_ID]. -> {"category": "billing", "reason": "double charge"}\n'
            'Ticket: Someone hacked my account and used my wallet. -> {"category": "fraud", "reason": "account takeover"}\n'
            'Ticket: The app freezes when I open the cart. -> {"category": "technical", "reason": "app problem"}\n'
            'Ticket: My order is very late and the rider is not answering. -> {"category": "delivery", "reason": "late delivery"}')
assert "CLASSIFY" in ZERO_SHOT and "EXAMPLES:" not in ZERO_SHOT and "EXAMPLES:" in FEW_SHOT

def redact(text, counter=None):
    for name, pat, ph in PATTERNS:
        text, n = pat.subn(ph, text)
        if counter is not None:
            counter[name] = counter.get(name, 0) + n
    return text

def call_with_retry(messages, ticket_id, stats, log):
    """Call the model; up to MAX_RETRIES retries with exponential backoff + jitter."""
    for attempt in range(MAX_RETRIES + 1):
        try:
            return mock_llm.chat(messages)
        except TransientLLMError:
            stats["transient_errors"] += 1
            if attempt == MAX_RETRIES:
                raise
            wait = BASE_DELAY * 2 ** attempt * random.uniform(0.9, 1.15)
            stats["waits"].append((attempt, wait))
            log(f"  retry ticket={ticket_id} retry_number={attempt} wait={wait:.4f}s")
            time.sleep(wait)
            stats["recovered"] += 1

def validate(content):
    """Returns (status, category). Never guesses."""
    try:
        obj = json.loads(content)
        if isinstance(obj, dict) and obj.get("category") in CATEGORIES:
            return "classified_json", obj["category"]
        return "flagged_invalid_output", ""
    except (json.JSONDecodeError, TypeError):
        words = set(re.findall(r"[a-z]+", (content or "").lower()))
        found = [c for c in CATEGORIES if c in words]
        if len(found) == 1:
            return "classified_keyword", found[0]
        return "flagged_invalid_output", ""

def run_pipeline(tickets, system_prompt, token_budget=None, log=print, sent_prompts=None):
    mock_llm.reset()                                   # immediately before each full run
    stats = {"transient_errors": 0, "recovered": 0, "waits": []}
    total_tokens, out = 0, []
    for t in tickets.itertuples():
        text = t.text
        rec = dict(ticket_id=t.ticket_id, customer_id=t.customer_id, status="", category="", tokens_used=0, true_category=t.true_category)
        if not text.strip():
            rec["status"] = "skipped_empty"
        elif est_tokens(text) > MAX_INPUT_TOKENS:
            rec["status"] = "flagged_long"
        elif token_budget is not None and total_tokens >= token_budget:
            rec["status"] = "budget_exhausted"
        else:
            msgs = [{"role": "system", "content": system_prompt}, {"role": "user", "content": redact(text)}]
            if sent_prompts is not None:
                sent_prompts.append(msgs)
            resp = call_with_retry(msgs, t.ticket_id, stats, log)
            used = resp.usage.total_tokens
            total_tokens += used
            rec["tokens_used"] = used
            rec["status"], rec["category"] = validate(resp.choices[0].message.content)
        out.append(rec)
    return pd.DataFrame(out), stats, total_tokens

def route(df, seg):
    seg = seg.set_index("customer_id")
    rows = []
    for r in df.itertuples():
        premium = bool(seg.is_premium.get(r.customer_id, False)) if r.customer_id in seg.index else False
        segname = seg.segment_name.get(r.customer_id, "") if r.customer_id in seg.index else ""
        if r.status in ("skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted"):
            rt, pr = "human_review", "NORMAL"
        elif r.category == "fraud":
            rt, pr = "security_team", "HIGH"
        elif premium:
            rt, pr = "premium_desk", "HIGH"
        else:
            rt, pr = "support_queue", "NORMAL"
        rows.append(dict(ticket_id=r.ticket_id, customer_id=r.customer_id, status=r.status, category=r.category,
                         segment_name=segname, priority=pr, route=rt, tokens_used=r.tokens_used))
    return pd.DataFrame(rows)

def accuracy(df):
    c = df[df.status.isin(["classified_json", "classified_keyword"])]
    return len(c), int((c.category == c.true_category).sum())

if __name__ == "__main__":
    import os
    os.makedirs("outputs", exist_ok=True)
    tickets = pd.read_csv("data/raw/tickets.csv", keep_default_na=False)
    seg = pd.read_csv("outputs/customer_segments.csv")

    print("=== TASK 1 INPUT GUARDRAILS ===")
    toks = tickets.text.map(est_tokens)
    print("empty tickets:", int((tickets.text.str.strip() == "").sum()), "| long (>%d tokens):" % MAX_INPUT_TOKENS, int((toks > MAX_INPUT_TOKENS).sum()),
          "| est tokens of long ones:", sorted(set(toks[toks > MAX_INPUT_TOKENS])))

    print("\n=== TASK 2 REDACTION ===")
    cnt = {}
    red = [redact(x, cnt) for x in tickets.text]
    print("substitutions:", cnt, "| total:", sum(cnt.values()))
    left = sum(len(p.findall(x)) for x in red for _, p, _ in PATTERNS)
    print("patterns found after redaction:", left); assert left == 0
    print("example:", tickets.text.iloc[0], "->", red[0])

    print("\n=== TASK 3 PROMPTS ===")
    print("zero-shot (%d est tokens):\n%s" % (est_tokens(ZERO_SHOT), ZERO_SHOT))
    print("few-shot (%d est tokens):\n%s" % (est_tokens(FEW_SHOT), FEW_SHOT))

    results = {}
    for name, prompt in [("zero-shot", ZERO_SHOT), ("few-shot", FEW_SHOT)]:
        print(f"\n=== FULL RUN: {name} (retry log) ===")
        sent = []
        df, st, tot = run_pipeline(tickets, prompt, None, sent_prompts=sent)
        results[name] = (df, st, tot)
        # privacy assertion: no email/phone/order id in any message sent (system or user)
        for msgs in sent:
            for m in msgs:
                for _, p, _ in PATTERNS:
                    assert not p.search(m["content"]), "PII leaked into prompt"
        assert all(len(m) == 2 for m in sent) and len(sent) == 156
        n, ok = accuracy(df)
        print(f"[{name}] model-call tickets: {len(sent)} | transient errors: {st['transient_errors']} | recovered by retry: {st['recovered']}")
        print(f"[{name}] retry waits all within range: {all(BASE_DELAY*2**a*0.9 <= w <= BASE_DELAY*2**a*1.15 for a, w in st['waits'])} | retry numbers used: {sorted(set(a for a,_ in st['waits']))} | min wait {min(w for _,w in st['waits']):.4f} max wait {max(w for _,w in st['waits']):.4f}")
        print(f"[{name}] status counts: {df.status.value_counts().to_dict()}")
        print(f"[{name}] classified: {n} | correct: {ok} | accuracy: {100*ok/n:.1f}% | total tokens: {tot} | tokens/classified ticket: {tot/n:.1f} | tokens/called ticket: {tot/len(sent):.1f}")
        print("PII-in-prompt assertion passed for all %d prompts" % len(sent))
    z = results["zero-shot"][0]
    zc = z[z.status.isin(["classified_json", "classified_keyword"])]
    print("\nZero-shot confusion table (rows=true, cols=predicted):\n", pd.crosstab(zc.true_category, zc.category).to_string())
    print("zero-shot errors:", zc[zc.category != zc.true_category].groupby(["true_category", "category"]).size().to_dict())

    print("\n=== TASK 6 BUDGET DEMO ===")
    for budget in (6000, 5000):
        d, st, tot = run_pipeline(tickets, ZERO_SHOT, token_budget=budget, log=lambda s: None)
        k = int((d.status == "budget_exhausted").sum())
        print(f"zero-shot TOKEN_BUDGET={budget}: budget_exhausted={k}, tokens used={tot}, status counts={d.status.value_counts().to_dict()}")
        if k > 0:
            demo = route(d, seg)
            demo.to_csv("outputs/triage_budget_demo.csv", index=False)
            print("saved outputs/triage_budget_demo.csv with budget", budget)
            break

    f, st, tot = run_pipeline(tickets, FEW_SHOT, token_budget=100000, log=lambda s: None)
    final = route(f, seg)
    final.to_csv("outputs/triage_results.csv", index=False)
    print("\n=== FINAL triage_results.csv (few-shot, budget 100000) ===")
    print("rows:", len(final), "| tokens:", tot)
    print("status:", final.status.value_counts().to_dict())
    print("route x priority:\n", final.groupby(["route", "priority"]).size().to_string())
    print("customers in tickets missing from segment file:", int((~tickets.customer_id.isin(seg.customer_id)).sum()), "tickets")
    auto = final.status.isin(["classified_json", "classified_keyword"]).sum()
    print("rule-validated and auto-routed:", int(auto), "| sent to human_review:", int((final.route == "human_review").sum()))
