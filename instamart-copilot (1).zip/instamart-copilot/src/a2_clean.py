"""Part A tasks 3-5: clean customers and orders, write CSVs + SQLite. Prints how many rows/values each rule changed."""
import sqlite3, pandas as pd, numpy as np
R, C = "data/raw/", "data/clean/"
cust = pd.read_csv(R + "customers.csv", keep_default_na=False, dtype=str)
prod = pd.read_csv(R + "products.csv")
orders = pd.read_csv(R + "orders.csv", keep_default_na=False, dtype=str)   # keep "N/A" as text

# ---------- customers ----------
raw_city = cust["city"].copy()
cust["city"] = cust["city"].str.strip().str.title()
print("C(a) city rows changed:", int((cust["city"] != raw_city).sum()), "| cities now:", cust["city"].nunique())
gmap = {"male": "male", "m": "male", "female": "female", "f": "female", "": "unknown"}
cust["gender"] = cust["gender"].str.strip().str.lower().map(gmap)
assert cust["gender"].notna().all()
age = pd.to_numeric(cust["age"].replace("", np.nan), errors="coerce")
bad = (age < 10) | (age > 100)
print("C(c) ages set to missing (out of 10-100):", int(bad.sum()))
age[bad] = np.nan
n_missing = int(age.isna().sum())
age = age.fillna(age.groupby(cust["city"]).transform("median"))
cust["age"] = age.round().astype(int)       # city medians are whole or .5 -> round; all stay in 18-60
print("C(c) ages imputed with city median:", n_missing)
cust["signup_date"] = pd.to_datetime(cust["signup_date"])
print("C cities:", cust["city"].value_counts().to_dict(), "| genders:", cust["gender"].value_counts().to_dict(),
      "| age range:", cust["age"].min(), cust["age"].max())

# ---------- orders ----------
n0 = len(orders)
orders["order_ts"] = pd.to_datetime(orders["order_ts"])                      # rule 1
d = int(orders.duplicated().sum()); orders = orders.drop_duplicates()        # rule 2
print(f"O rule2 exact duplicates removed: {d} -> {len(orders)} rows")
before = len(orders)                                                         # rule 3
orders = orders.sort_values(["order_id", "order_ts"]).drop_duplicates("order_id", keep="last")
print(f"O rule3 earlier records dropped (kept latest order_ts per order_id): {before - len(orders)} -> {len(orders)} rows")
orders = orders.sort_values("order_ts").reset_index(drop=True) if False else orders.reset_index(drop=True)
for c in ["quantity", "discount_pct"]: orders[c] = orders[c].astype(int)
orders["order_amount"] = pd.to_numeric(orders["order_amount"], errors="coerce")   # rule 4
miss = orders["order_amount"].isna()
price = orders["product_id"].map(prod.set_index("product_id")["price_inr"])
calc = (price * orders["quantity"] * (1 - orders["discount_pct"] / 100)).round(2)
orders.loc[miss, "order_amount"] = calc[miss]
print("O rule4 unparseable amounts refilled from price:", int(miss.sum()), "(among surviving rows)")
dm = pd.to_numeric(orders["delivery_minutes"].replace("", np.nan), errors="coerce")  # rule 5
neg = dm < 0; dm[neg] = np.nan
print("O rule5 negative delivery_minutes set to missing:", int(neg.sum()))
orders["delivery_minutes"] = dm
comp = orders["status"] == "completed"
cat = orders["product_id"].map(prod.set_index("product_id")["category"])
med = dm.where(comp).groupby(cat).transform("median")   # median among completed only, per product category
fill = comp & dm.isna()
orders.loc[fill, "delivery_minutes"] = med[fill]
print("O rule5 completed delivery_minutes imputed with category median:", int(fill.sum()),
      "| cancelled left missing:", int((~comp & orders['delivery_minutes'].isna()).sum()))
print("O result rows:", len(orders), orders["status"].value_counts().to_dict(),
      "| missing amount:", int(orders['order_amount'].isna().sum()),
      "| completed missing delivery:", int(orders.loc[comp, 'delivery_minutes'].isna().sum()),
      "| completed revenue: INR", round(orders.loc[comp, 'order_amount'].sum(), 2))

# ---------- store ----------
cust.to_csv(C + "customers.csv", index=False); prod.to_csv(C + "products.csv", index=False)
orders["order_ts"] = orders["order_ts"].dt.strftime("%Y-%m-%d %H:%M:%S")
orders.to_csv(C + "orders.csv", index=False)
cdb = cust.copy(); cdb["signup_date"] = cdb["signup_date"].dt.strftime("%Y-%m-%d")
with sqlite3.connect("data/instamart.db") as con:
    for n, df in [("customers", cdb), ("products", prod), ("orders", orders)]:
        df.to_sql(n, con, if_exists="replace", index=False)
    print("DB tables:", [r[0] for r in con.execute("select name from sqlite_master where type='table'")])
