"""Part A task 2: audit the raw tables."""
import pandas as pd
R = "data/raw/"
cust = pd.read_csv(R + "customers.csv"); prod = pd.read_csv(R + "products.csv"); orders = pd.read_csv(R + "orders.csv")
for name, df in [("customers", cust), ("products", prod), ("orders", orders)]:
    print(f"\n== {name}: shape={df.shape}")
    t = pd.DataFrame({"dtype": df.dtypes.astype(str), "missing": df.isna().sum(), "missing_pct": (df.isna().mean() * 100).round(2)})
    print(t.to_string())
# pandas silently turns the literal text "N/A" into NaN on load, so count unparseable amounts from the raw strings
raw_amt = pd.read_csv(R + "orders.csv", keep_default_na=False, dtype=str)["order_amount"]
amt = pd.to_numeric(raw_amt, errors="coerce")
dm = pd.to_numeric(orders["delivery_minutes"], errors="coerce")
age = pd.to_numeric(cust["age"], errors="coerce")
audit = {
 "orders raw rows": len(orders),
 "exact duplicate rows": int(orders.duplicated().sum()),
 "pending rows": int((orders["status"] == "pending").sum()),
 "distinct order_id": int(orders["order_id"].nunique()),
 "non-numeric order_amount": int(amt.isna().sum()),
 "negative delivery_minutes": int((dm < 0).sum()),
 "blank delivery_minutes": int(orders["delivery_minutes"].isna().sum()),
 "customers blank age": int(cust["age"].isna().sum()),
 "ages outside 10-100": int(((age < 10) | (age > 100)).sum()),
 "distinct raw city spellings": int(cust["city"].nunique()),
 "distinct non-blank gender spellings": int(cust["gender"].dropna().nunique()),
 "blank gender": int(cust["gender"].isna().sum()),
}
print("\n== AUDIT FIGURES")
for k, v in audit.items(): print(f"{k}: {v}")
