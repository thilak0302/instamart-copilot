"""Part B tasks 4-8: lapse cohort, leakage-free preprocessing, tuning, balance experiment, persistence, retention list."""
import warnings; warnings.filterwarnings("ignore")
import joblib, numpy as np, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, accuracy_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CUT = pd.Timestamp("2025-09-01"); END = pd.Timestamp("2025-10-01")
o = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
c = pd.read_csv("data/clean/customers.csv", parse_dates=["signup_date"])
p = pd.read_csv("data/clean/products.csv")
o = o.merge(p[["product_id", "category"]], on="product_id")

pre = o[o.order_ts < CUT]                       # ONLY orders before the cutoff feed features
done = pre[pre.status == "completed"]
cohort_ids = done.customer_id.unique()
f = done.groupby("customer_id").agg(last=("order_ts", "max"), frequency=("order_id", "nunique"), monetary=("order_amount", "sum"),
                                    avg_discount=("discount_pct", "mean"), avg_delivery=("delivery_minutes", "mean"))
f["recency"] = (CUT - f["last"]).dt.days
canc = pre[pre.status == "cancelled"].groupby("customer_id").size()
f["cancel_rate"] = (canc.reindex(f.index).fillna(0) / pre.groupby("customer_id").size().reindex(f.index))
# favourite category: most frequent among completed orders, ties -> alphabetical (deterministic)
fav = done.groupby(["customer_id", "category"]).size().reset_index(name="n").sort_values(["customer_id", "n", "category"], ascending=[True, False, True])
f["fav_category"] = fav.drop_duplicates("customer_id").set_index("customer_id")["category"]
f = f.drop(columns="last").reset_index().merge(c, on="customer_id")
f["tenure_days"] = (CUT - f["signup_date"]).dt.days
# label: no completed order in Sept
sept = o[(o.order_ts >= CUT) & (o.order_ts < END) & (o.status == "completed")].customer_id.unique()
f["lapsed"] = (~f.customer_id.isin(sept)).astype(int)

NUM = ["recency", "frequency", "monetary", "avg_discount", "cancel_rate", "avg_delivery", "age", "tenure_days"]
CAT = ["city", "gender", "fav_category"]
X, y = f[["customer_id"] + NUM + CAT], f["lapsed"]
assert not X[NUM + CAT].isna().any().any(), "missing values in features"
print("No missing values in any feature column: confirmed")
print(f"cohort={len(f)} lapsed={int(y.sum())} ({y.mean()*100:.2f}%)")
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
print("train/test:", len(Xtr), len(Xte), "| train class counts:", ytr.value_counts().to_dict())
base = np.zeros(len(yte), dtype=int)
print(f"baseline always-not-lapsed: acc={accuracy_score(yte, base)*100:.1f}% F1={f1_score(yte, base, zero_division=0)}")

def prep():
    return ColumnTransformer([("num", StandardScaler(), NUM), ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), CAT)])
def pipe(clf): return Pipeline([("prep", prep()), ("clf", clf)])
FEATS = NUM + CAT
lr_gs = GridSearchCV(pipe(LogisticRegression(max_iter=1000)), {"clf__C": [0.01, 0.1, 1, 10, 100]}, cv=5, scoring="f1").fit(Xtr[FEATS], ytr)
rf_gs = GridSearchCV(pipe(RandomForestClassifier(n_estimators=100, random_state=42)),
                     {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [5, 10, 20]}, cv=5, scoring="f1").fit(Xtr[FEATS], ytr)
print("\nLR best:", lr_gs.best_params_, "cv F1", round(lr_gs.best_score_, 4))
print("RF best:", rf_gs.best_params_, "cv F1", round(rf_gs.best_score_, 4))

sc = lr_gs.best_estimator_.named_steps["prep"].named_transformers_["num"]
print(f"\nScaler learned mean(frequency)={sc.mean_[NUM.index('frequency')]:.4f} (train rows) vs full-cohort mean={f.frequency.mean():.4f}")

def ev(m, name, Xe=Xte[FEATS]):
    pr = m.predict(Xe)
    r = dict(model=name, precision=precision_score(yte, pr, zero_division=0), recall=recall_score(yte, pr, zero_division=0), f1=f1_score(yte, pr, zero_division=0))
    print(f"{name}: confusion [[TN FP],[FN TP]] = {confusion_matrix(yte, pr).tolist()} | P={r['precision']:.3f} R={r['recall']:.3f} F1={r['f1']:.3f}")
    return r
print("\nTEST SET (after tuning)")
r_lr = ev(lr_gs.best_estimator_, "LogReg"); r_rf = ev(rf_gs.best_estimator_, "RandForest")

# ---- class balance experiment (oversample TRAIN only; original rows kept)
rng_state = 42
tr = Xtr.copy(); tr["lapsed"] = ytr.values
mino = tr[tr.lapsed == 1]; maj = tr[tr.lapsed == 0]
extra = mino.sample(n=len(maj) - len(mino), replace=True, random_state=rng_state)
bal = pd.concat([tr, extra]); print("\nbalanced train counts:", bal.lapsed.value_counts().to_dict())
lr_bal = pipe(LogisticRegression(max_iter=1000, C=lr_gs.best_params_["clf__C"])).fit(bal[FEATS], bal["lapsed"])
r_bal = ev(lr_bal, "LogReg+oversample")

# ---- interpretation
names = rf_gs.best_estimator_.named_steps["prep"].get_feature_names_out()
imp = pd.Series(rf_gs.best_estimator_.named_steps["clf"].feature_importances_, index=names).sort_values(ascending=False)
print("\nTop-5 RF importances:\n", imp.head(5).round(4).to_string())
lnames = lr_gs.best_estimator_.named_steps["prep"].get_feature_names_out()
coef = pd.Series(lr_gs.best_estimator_.named_steps["clf"].coef_[0], index=lnames)
print("\nLR coefficients (selected):\n", coef[["num__recency", "num__frequency", "num__tenure_days", "num__monetary", "num__avg_discount"]].round(3).to_string())

# ---- select, persist, reload
chosen_name = "RandForest" if r_rf["f1"] >= r_lr["f1"] else "LogReg"
chosen = rf_gs.best_estimator_ if chosen_name == "RandForest" else lr_gs.best_estimator_
print("\nSelected model:", chosen_name, "test F1 =", round(max(r_rf['f1'], r_lr['f1']), 3))
joblib.dump(chosen, "outputs/lapse_model.joblib")
re = joblib.load("outputs/lapse_model.joblib")
same = np.array_equal(re.predict(Xte[FEATS]), chosen.predict(Xte[FEATS])) and np.allclose(re.predict_proba(Xte[FEATS]), chosen.predict_proba(Xte[FEATS]))
print("Reloaded model reproduces test predictions exactly:", same); assert same

# ---- retention list
seg = pd.read_csv("outputs/customer_segments.csv")
te = Xte[["customer_id"]].copy(); te["lapse_probability"] = chosen.predict_proba(Xte[FEATS])[:, 1]; te["actually_lapsed"] = yte.values
te = te.merge(seg[["customer_id", "is_premium"]], on="customer_id", how="left"); te["is_premium"] = te.is_premium.fillna(False).astype(bool)
prem = te[te.is_premium].sort_values("lapse_probability", ascending=False)
print(f"\nPremium customers in test set: {len(prem)}")
top = prem.head(10)[["customer_id", "lapse_probability", "actually_lapsed"]].round(4)
top.to_csv("outputs/retention_list.csv", index=False)
print(top.to_string(index=False)); print("truly lapsed among list:", int(top.actually_lapsed.sum()), "of", len(top))
