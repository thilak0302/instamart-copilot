"""Part C: ticket triage with guardrails, redaction, retries, output validation, token budget and routing."""
import json, random, re, time
import pandas as pd
import mock_llm
from mock_llm import est_tokens, TransientLLMError

MAX_INPUT_TOKENS = 400
BASE_DELAY = 0.05
MAX_RETRIES = 3
CATEGORIES = ["billing", "delivery", "technical", "fraud"]
PATTERNS = [("EMAIL", re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[EMAIL]"),
            ("PHONE", re.compile(r"\b[6-9]\d{9}\b"), "[PHONE]"),
            ("ORDER_ID", re.compile(r"ORD-\d{6}"), "[ORDER_ID]")]

ZERO_SHOT = ('You CLASSIFY support tickets. Allowed categories: billing, delivery, technical, fraud. '
             'Reply with JSON only: {"category": "...", "reason": "..."}')
FEW_SHOT = ('You CLASSIFY support tickets. Allowed categories: billing, delivery, technical, fraud. '
            'Reply with JSON only: {"category": "...", "reason": "..."}\n'
            'EXAMPLES:\n'
            'Ticket: Someone used my card without my consent, I did not place this order. -> {"category": "fraud", "reason": "unauthorized use"}\n'
            'Ticket: The app freezes and shows an error at checkout. -> {"category": "technical", "reason": "app problem"}\n'
            'Ticket: I was charged twice for the same order. -> {"category": "billing", "reason": "double charge"}\n'
            'Ticket: My rider never arrived with the package. -> {"category": "delivery", "reason": "missing delivery"}')

def redact(text, counts=None):
    for name, pat, ph in PATTERNS:
        text, n = pat.subn(ph, text)
        if counts is not None: counts[name] += n
    return text

def pii_left(text):
    return sum(len(pat.findall(text)) for _, pat, _ in PATTERNS)

RETRY_LOG = []
def call_with_retry(messages, ticket_id):
    """Up to MAX_RETRIES retries; wait = BASE_DELAY * 2**n * U(0.9, 1.15); one log line per retry."""
    for n in range(MAX_RETRIES + 1):
        try:
            return mock_llm.chat(messages)
        except TransientLLMError as e:
            if n == MAX_RETRIES: raise
            wait = BASE_DELAY * 2 ** n * random.uniform(0.9, 1.15)
            RETRY_LOG.append((ticket_id, n, wait))
            print(f"[retry] ticket={ticket_id} retry_number={n} wait={wait:.4f}s ({e})")
            time.sleep(wait)

def validate(content):
    """-> (status, category). Never guesses."""
    try:
        d = json.loads(content)
        if isinstance(d, dict) and d.get("category") in CATEGORIES:
            return "classified_json", d["category"]
        return "flagged_invalid_output", ""
    except (json.JSONDecodeError, TypeError):
        pass
    found = [w for w in re.findall(r"[a-z]+", (content or "").lower()) if w in CATEGORIES]
    if len(set(found)) == 1 and len(found) == 1:
        return "classified_keyword", found[0]
    return "flagged_invalid_output", ""

def run_pipeline(tickets, system_prompt, token_budget=None, seed=0):
    """Process tickets in file order; returns DataFrame (ticket_id, customer_id, status, category, tokens_used, true_category)."""
    random.seed(seed); RETRY_LOG.clear(); mock_llm.reset()
    total, rows, model_calls = 0, [], 0
    for t in tickets.itertuples():
        text = t.text; status = cat = ""; used = 0
        if not text.strip():
            status = "skipped_empty"
        elif est_tokens(text) > MAX_INPUT_TOKENS:
            status = "flagged_long"
        elif token_budget is not None and total >= token_budget:
            status = "budget_exhausted"
        else:
            safe = redact(text)
            messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": safe}]
            assert messages[1]["content"] == safe and pii_left(" ".join(m["content"] for m in messages)) == 0, "PII reached prompt"
            resp = call_with_retry(messages, t.ticket_id); model_calls += 1
            used = resp.usage.total_tokens; total += used
            status, cat = validate(resp.choices[0].message.content)
        rows.append(dict(ticket_id=t.ticket_id, customer_id=t.customer_id, status=status, category=cat, tokens_used=used, true_category=t.true_category))
    df = pd.DataFrame(rows); df.attrs.update(total_tokens=total, model_calls=model_calls)
    return df

def route(df, seg_path="outputs/customer_segments.csv"):
    seg = pd.read_csv(seg_path).set_index("customer_id")
    out = []
    for r in df.itertuples():
        in_seg = r.customer_id in seg.index
        premium = bool(seg.loc[r.customer_id, "is_premium"]) if in_seg else False
        segname = seg.loc[r.customer_id, "segment_name"] if in_seg else ""
        if r.status in ("skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted"):
            rt, pr = "human_review", "NORMAL"
        elif r.category == "fraud":
            rt, pr = "security_team", "HIGH"
        elif premium:
            rt, pr = "premium_desk", "HIGH"
        else:
            rt, pr = "support_queue", "NORMAL"
        out.append(dict(ticket_id=r.ticket_id, customer_id=r.customer_id, status=r.status, category=r.category,
                        segment_name=segname, priority=pr, route=rt, tokens_used=r.tokens_used))
    return pd.DataFrame(out)

def accuracy(df):
    c = df[df.status.isin(["classified_json", "classified_keyword"])]
    return len(c), int((c.category == c.true_category).sum())

if __name__ == "__main__":
    tickets = pd.read_csv("data/raw/tickets.csv", keep_default_na=False, dtype=str)
    # --- guardrail + redaction figures
    est = tickets.text.map(est_tokens)
    print("empty:", int((~tickets.text.str.strip().astype(bool)).sum()), "| long (>400 est tokens):", int((est > MAX_INPUT_TOKENS).sum()),
          "| long est tokens:", sorted(set(est[est > MAX_INPUT_TOKENS])))
    counts = {"EMAIL": 0, "PHONE": 0, "ORDER_ID": 0}
    red = tickets.text.map(lambda s: redact(s, counts))
    print("redactions:", counts, "total", sum(counts.values()), "| PII left after redaction:", int(red.map(pii_left).sum()))
    print("prompts: zero-shot has EXAMPLES:", "EXAMPLES:" in ZERO_SHOT, "| few-shot has EXAMPLES:", "EXAMPLES:" in FEW_SHOT,
          "| est tokens zero/few:", est_tokens(ZERO_SHOT), est_tokens(FEW_SHOT))
    # --- zero-shot vs few-shot, no budget
    res = {}
    for name, sp in [("zero-shot", ZERO_SHOT), ("few-shot", FEW_SHOT)]:
        print(f"\n===== {name} full run =====")
        df = run_pipeline(tickets, sp); res[name] = df
        waits = [w for _, _, w in RETRY_LOG]
        print(f"transient errors recovered: {len(RETRY_LOG)} | retry numbers: {sorted(set(n for _, n, _ in RETRY_LOG))} | wait range: {min(waits):.4f}-{max(waits):.4f}s")
        print("status counts:", df.status.value_counts().to_dict())
        n, ok = accuracy(df); tok = df.attrs["total_tokens"]
        print(f"classified={n} correct={ok} accuracy={ok/n*100:.1f}% total_tokens={tok} tokens/classified={tok/n:.1f} model_calls={df.attrs['model_calls']}")
    z = res["zero-shot"]; zc = z[z.status.isin(["classified_json", "classified_keyword"])]
    print("\nZero-shot confusion (rows=true, cols=predicted):")
    print(pd.crosstab(zc.true_category, zc.category).to_string())
    # --- budget demo (zero-shot)
    df = run_pipeline(tickets, ZERO_SHOT, token_budget=6000)
    bd = route(df); bd.to_csv("outputs/triage_budget_demo.csv", index=False)
    print("\nBUDGET DEMO (zero-shot, TOKEN_BUDGET=6000): status counts", df.status.value_counts().to_dict(), "| tokens spent", df.attrs["total_tokens"])
    # --- final routed output (few-shot, 100000)
    df = run_pipeline(tickets, FEW_SHOT, token_budget=100000)
    fin = route(df); fin.to_csv("outputs/triage_results.csv", index=False)
    print("\nFINAL (few-shot, budget 100000): rows", len(fin), "| status", df.status.value_counts().to_dict())
    print("route counts:", fin.route.value_counts().to_dict()); print("priority counts:", fin.priority.value_counts().to_dict())
    print(pd.crosstab(fin.route, fin.priority).to_string())
    print("no-segment customers:", int((fin.segment_name == "").sum()))
