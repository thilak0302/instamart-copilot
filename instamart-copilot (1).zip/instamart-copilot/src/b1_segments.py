"""Part B tasks 1-3: RFM, K-means sweep, final K=4 profile, PCA, outputs/customer_segments.csv"""
import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

o = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"]); o = o[o.status == "completed"]
snap = pd.Timestamp("2025-10-01 00:00:00")
g = o.groupby("customer_id").agg(last=("order_ts", "max"), frequency=("order_id", "nunique"), monetary=("order_amount", "sum"))
g["recency"] = (snap - g["last"]).dt.days
rfm = g[["recency", "frequency", "monetary"]].reset_index()
print("RFM customers:", len(rfm), "| recency median/min/max:", rfm.recency.median(), rfm.recency.min(), rfm.recency.max(),
      "| frequency mean/max:", round(rfm.frequency.mean(), 2), rfm.frequency.max(),
      "| monetary mean/max:", round(rfm.monetary.mean(), 2), round(rfm.monetary.max(), 2))

X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
print("\nK | inertia | silhouette")
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    print(k, round(km.inertia_, 1), round(silhouette_score(X, km.labels_), 3))

K = 4
km = KMeans(n_clusters=K, n_init=10, random_state=42).fit(X)
rfm["segment_id"] = km.labels_
prof = rfm.groupby("segment_id").agg(size=("customer_id", "count"), recency=("recency", "mean"),
                                     frequency=("frequency", "mean"), monetary=("monetary", "mean")).round(1)
# Names assigned by RULE on the profile (cluster ids carry no order)
premium = prof.monetary.idxmax()
rest = prof.drop(premium)
loyal = rest.frequency.idxmax(); dormant = rest.drop(loyal).recency.idxmax()
occasional = [i for i in prof.index if i not in (premium, loyal, dormant)][0]
names = {premium: "Premium Big-Ticket", loyal: "Loyal Regulars", dormant: "Dormant At-Risk", occasional: "Occasional Shoppers"}
actions = {"Premium Big-Ticket": "VIP perks, early access to electronics launches, dedicated premium support desk",
           "Loyal Regulars": "Subscription / basket-builder offers, protect with free-delivery thresholds",
           "Dormant At-Risk": "Win-back coupon plus reminder push before they churn for good",
           "Occasional Shoppers": "Nudge to 2nd/3rd order per month with category bundles"}
rfm["segment_name"] = rfm.segment_id.map(names); rfm["is_premium"] = rfm.segment_id == premium
prof["name"] = prof.index.map(names); prof["action"] = prof["name"].map(actions); prof["premium"] = prof.index == premium
print("\nSegment profile (cluster numbers are arbitrary labels, no ordering):\n", prof.to_string())
p = PCA(n_components=2).fit(X)
print("\nPCA explained_variance_ratio_:", p.explained_variance_ratio_.round(3), "total", p.explained_variance_ratio_.sum().round(3))
rfm[["customer_id", "recency", "frequency", "monetary", "segment_id", "segment_name", "is_premium"]].round(2).to_csv("outputs/customer_segments.csv", index=False)
print("premium rows:", int(rfm.is_premium.sum()))
