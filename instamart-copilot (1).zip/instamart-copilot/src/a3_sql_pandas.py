"""Part A tasks 6-7: run the 7 SQL queries from Python, then pandas cross-check + EDA."""
import re, sqlite3, pandas as pd, numpy as np
con = sqlite3.connect("data/instamart.db")
blocks = [b.strip() for b in re.split(r"^-- Q\d+:.*$", open("sql/queries.sql").read(), flags=re.M)[1:]]
q = {i + 1: pd.read_sql_query(b.rstrip(";"), con) for i, b in enumerate(blocks)}
assert len(q) == 7
print("Q1 customers:", len(q[1]))
print("Q2 rows:", len(q[2]), "| total:", round(q[2].revenue.sum(), 2), "| largest:", q[2].iloc[0].to_dict())
print("Q3 products:", len(q[3]))
print("Q4 customers without completed order:", len(q[4]))
print("Q5 customers above avg:", len(q[5]), "| avg:", q[5].avg_total.iloc[0])
q6 = q[6]; top = q6[q6.row_num == 1][["city", "customer_id", "total_spend"]]
print("Q6 top per city:\n", top.to_string(index=False))
print("Q6 rows where RANK != ROW_NUMBER:", int((q6.rnk != q6.row_num).sum()))
print("Q7 rows:", len(q[7]), "| last cumulative:", q[7].cumulative_revenue.iloc[-1])

# ---- pandas cross-check
o = pd.read_sql_query("select * from orders", con); c = pd.read_sql_query("select * from customers", con)
p = pd.read_sql_query("select * from products", con)
done = o[o.status == "completed"].merge(c, on="customer_id").merge(p, on="product_id")
pv = pd.pivot_table(done, values="order_amount", index="city", columns="category", aggfunc="sum", margins=True)
print("\nPivot grand total:", round(pv.loc["All", "All"], 2), "| equals SQL total:", abs(pv.loc["All", "All"] - q[2].revenue.sum()) < 0.01)
g = done.groupby("city").agg(total=("order_amount", "sum"),
                             mean=("order_amount", "mean"), n=("order_amount", "count")).round(2)
print(g.to_string())

# ---- EDA on completed order_amount
d = o[o.status == "completed"]; x = d.order_amount
q1, q3 = x.quantile(.25), x.quantile(.75); iqr = q3 - q1; lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
print(f"\nmean {x.mean():.2f} median {x.median():.2f} skew {x.skew():.2f} Q1 {q1:.2f} Q3 {q3:.2f} IQR {iqr:.2f}")
print(f"fences low {lo:.2f} high {hi:.2f} | outliers below {int((x < lo).sum())} above {int((x > hi).sum())}")
cm = d[["order_amount", "discount_pct", "quantity", "delivery_minutes"]].corr().round(3)
print(cm.to_string())
pairs = cm.where(np.triu(np.ones(cm.shape), 1).astype(bool)).stack()
print("largest |corr|:", pairs.abs().idxmax(), pairs[pairs.abs().idxmax()])
