import pandas as pd, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
o = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"]); o = o[o.status == "completed"]
snap = pd.Timestamp("2025-10-01 00:00:00")
g = o.groupby("customer_id").agg(last=("order_ts", "max"), frequency=("order_id", "nunique"), monetary=("order_amount", "sum"))
g["recency"] = (snap - g["last"]).dt.days
rfm = g[["recency", "frequency", "monetary"]].reset_index()
print(len(rfm), rfm.recency.median(), rfm.recency.min(), rfm.recency.max(), round(rfm.frequency.mean(), 2), rfm.frequency.max(), round(rfm.monetary.mean(), 2), rfm.monetary.max())
X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    print(k, round(km.inertia_, 1), round(silhouette_score(X, km.labels_), 3))
for k in (3, 4, 5):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    rfm["s"] = km.labels_
    print(k); print(rfm.groupby("s")[["recency", "frequency", "monetary"]].mean().round(1).assign(n=rfm.s.value_counts().sort_index()))
p = PCA(n_components=2).fit(X); print(p.explained_variance_ratio_.round(3), p.explained_variance_ratio_.sum().round(3))
