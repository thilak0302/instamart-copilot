"""Part A task 5: assert reference checkpoints on the clean data and the database."""
import sqlite3, pandas as pd
c = pd.read_csv("data/clean/customers.csv"); o = pd.read_csv("data/clean/orders.csv")
con = sqlite3.connect("data/instamart.db")
done = o[o.status == "completed"]
checks = {
 "orders rows == 12309": len(o) == 12309,
 "order_id unique": o.order_id.is_unique,
 "11110 completed / 1199 cancelled": (o.status.value_counts().to_dict() == {"completed": 11110, "cancelled": 1199}),
 "no pending rows": not (o.status == "pending").any(),
 "0 missing order_amount": o.order_amount.isna().sum() == 0,
 "0 missing delivery (completed)": done.delivery_minutes.isna().sum() == 0,
 "1199 missing delivery (cancelled)": o[o.status == "cancelled"].delivery_minutes.isna().sum() == 1199,
 "completed revenue == 2998668.80": round(done.order_amount.sum(), 2) == 2998668.80,
 "six cities with reference counts": c.city.value_counts().to_dict() == {"Pune": 227, "Delhi": 210, "Bengaluru": 197, "Chennai": 191, "Hyderabad": 191, "Mumbai": 184},
 "genders 610/560/30": c.gender.value_counts().to_dict() == {"female": 610, "male": 560, "unknown": 30},
 "0 missing ages, all in 18-60": c.age.isna().sum() == 0 and c.age.between(18, 60).all(),
 "DB has 3 tables": {r[0] for r in con.execute("select name from sqlite_master where type='table'")} == {"customers", "products", "orders"},
 "DB order count matches CSV": con.execute("select count(*) from orders").fetchone()[0] == 12309,
 "DB revenue matches": round(con.execute("select sum(order_amount) from orders where status='completed'").fetchone()[0], 2) == 2998668.80,
}
bad = [k for k, v in checks.items() if not v]
for k, v in checks.items(): print(("PASS " if v else "FAIL ") + k)
assert not bad, f"failed: {bad}"
print("ALL CHECKPOINTS PASSED")
